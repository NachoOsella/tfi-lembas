---
title: Documentación TPF Lembas
tags:
  - tpf
  - indice
  - obsidian
aliases:
  - Índice TPF Lembas
---

# Documentación TPF Lembas

> [!abstract]
> Índice general de la documentación del trabajo práctico final.

## Nota central

- [[00 - TPF Dietética Lembas|TPF Dietética Lembas]]

## Secciones

- [[01 - Contexto y objetivo]]
- [[02 - Alcance funcional]]
- [[03 - Requisitos funcionales]]
- [[04 - Reglas de negocio]]
- [[05 - Arquitectura y tecnología]]
- [[06 - Roadmap y futuras mejoras]]
- [[07 - Modelo de datos conceptual]]
- [[08 - Casos de uso]]
- [[09 - Plan de sprints]]
