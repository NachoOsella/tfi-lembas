# Lembas - Propuesta funcional para dietética

Documento pensado para presentar a la dueña del negocio. Resume el alcance, las funcionalidades principales y cómo el sistema ayudaría en el trabajo diario del local, sin entrar en detalles técnicos.

> **Idea principal:** Lembas busca centralizar productos, stock, vencimientos, ventas simples, caja del turno, proveedores, listas de precios y tareas operativas en una sola herramienta clara y fácil de usar.

## Vista inicial del sistema

![Pantalla de inicio de sesión](attachments/lembas-login.png)

## Qué problemas busca resolver

- Evitar errores por carga manual o datos desactualizados.
- Saber qué productos hay, cuántos quedan y cuáles vencen pronto.
- Registrar ventas simples con scanner y descontar stock automáticamente.
- Controlar la caja del turno sin convertir el sistema en una solución contable compleja.
- Ordenar listas de precios de varios proveedores, aunque lleguen en formatos distintos.
- Comparar costos nuevos contra costos anteriores antes de aplicar cambios.
- Actualizar precios de venta con revisión y generar etiquetas cuando corresponda.
- Tener roles diferenciados para que cada persona vea solo lo que necesita.

## Alcance general

- Productos.
- Stock.
- Vencimientos.
- Ventas mostrador.
- Caja del turno.
- Proveedores.
- Listas de precios.
- Actualización de precios.
- Consumo interno.
- Ofertas temporales.
- Etiquetas.
- Tareas del día.

## Fuera de alcance por ahora

- Facturación fiscal o integración con AFIP.
- Pasarelas de pago o integración automática con tarjetas/Mercado Pago.
- E-commerce o tienda online.
- Sistema contable completo.
- Gestión de múltiples sucursales.
- Cuenta corriente de clientes o CRM avanzado.
- Lectura automática de listas desde PDF o imágenes, porque requeriría OCR y aumentaría demasiado la complejidad.

## Roles dentro del sistema

### Dueña / Administradora

Puede gestionar productos, precios, ofertas, stock, proveedores, listas de precios, caja, empleados, reportes, ajustes y reglas del negocio.

![Home de administración](attachments/lembas-home-admin.png)

### Empleado

Puede registrar ventas, consultar precios y stock, revisar tareas asignadas, cargar consumo interno autorizado, registrar mermas permitidas y cerrar su turno. No debería ver reportes generales sensibles, configuración global, ganancias amplias, administración de usuarios ni aplicar cambios masivos de precios sin autorización.

![Home de empleado](attachments/lembas-home-empleado-refinada.png)

## Proveedores y listas de precios

La dietética puede trabajar con varios proveedores, y no todos envían la información de la misma manera. El sistema debe permitir cargar listas de precios de forma flexible y revisarlas antes de aplicar cambios.

### Métodos de carga incluidos

- **Excel:** para proveedores que mandan una planilla con productos, presentaciones y precios.
- **Texto de WhatsApp:** para listas que llegan como mensaje escrito y pueden copiarse y pegarse en el sistema.
- **Carga manual:** para cambios puntuales, listas chicas o proveedores menos ordenados.

> No se incluye lectura automática desde PDF, fotos o imágenes. Esa funcionalidad requeriría OCR y puede complicar demasiado el proyecto.

### Flujo de lista de precios

1. Proveedor envía lista por Excel o WhatsApp.
2. La información se carga en Lembas.
3. El sistema intenta reconocer productos.
4. Se comparan costos nuevos contra anteriores.
5. La dueña aprueba cambios.
6. Se actualizan costos y precios seleccionados.
7. Se generan etiquetas si corresponde.
8. Se arma pedido de reposición si hace falta.

## Actualización de costos y precios

El sistema diferencia entre costo del proveedor y precio de venta al público.

- **Costo del proveedor:** lo que la dietética paga o pagaría al comprar.
- **Precio de venta:** lo que se cobra al cliente en mostrador.
- **Margen estimado:** diferencia entre costo y precio de venta.
- **Precio sugerido:** precio que propone el sistema según una regla definida.

## Venta mostrador simplificada

- Escanear productos con código de barras.
- Buscar productos manualmente si no tienen código.
- Agregar varios productos a una misma venta.
- Modificar cantidad antes de confirmar.
- Modificar precio cuando esté permitido.
- Aplicar ofertas temporales vigentes.
- Confirmar venta y descontar stock automáticamente.
- Registrar ingreso en caja del turno.

## Stock, consumo interno y motivos de descuento

No todo egreso de stock es una venta. El sistema debe diferenciar:

- Venta.
- Consumo interno.
- Merma.
- Vencimiento.
- Ajuste de inventario.
- Devolución.

## Valor esperado

- Menos dependencia de planillas, mensajes sueltos y anotaciones manuales.
- Mayor control del stock real.
- Menos pérdidas por vencimientos no detectados.
- Ventas más rápidas con scanner.
- Caja del turno más ordenada.
- Mayor control sobre consumos internos y mermas.
- Mejor comparación de costos entre proveedores.
- Actualización de precios más controlada y con menos errores.
- Etiquetas nuevas cuando cambian precios de venta.
- Diferentes vistas para dueña y empleados.
