---
title: Requisitos funcionales
aliases:
  - RF del sistema
  - Requerimientos funcionales
  - Matriz de requisitos funcionales Lembas
tags:
  - tpf
  - requisitos
  - funcionales
  - analisis
  - trazabilidad
cssclasses:
  - wide-page
---

# Requisitos funcionales

> [!abstract]
> Listado actualizado de requisitos funcionales para Lembas. Los requisitos están alineados con [[00 - TPF Dietética Lembas]] y cubren usuarios, productos, stock, venta mostrador simplificada, ofertas, consumo interno, caja, proveedores, listas de precios, actualización asistida, reposición, pedidos, recepción, etiquetas, reportes, alertas, auditoría e interfaz mobile-first.

## Requisitos de autenticación, usuarios y roles

| ID | Requisito |
|---|---|
| RF-01 | El sistema debe permitir iniciar sesión con credenciales válidas. |
| RF-02 | El sistema debe permitir cerrar sesión de manera segura. |
| RF-03 | El sistema debe permitir administrar usuarios mediante alta, edición, consulta y baja lógica. |
| RF-04 | El sistema debe permitir asignar roles a los usuarios. |
| RF-05 | El sistema debe diferenciar al menos los roles Administradora/Dueña y Empleado. |
| RF-06 | El sistema debe restringir funcionalidades según rol y permisos. |
| RF-07 | El sistema debe impedir que usuarios inactivos operen. |
| RF-08 | El sistema debe registrar usuario, fecha y hora de acciones sensibles. |

## Requisitos de productos, categorías y marcas

| ID | Requisito |
|---|---|
| RF-09 | El sistema debe permitir crear, editar, consultar y desactivar productos. |
| RF-10 | El sistema debe almacenar nombre, descripción, categoría, marca y presentación del producto. |
| RF-11 | El sistema debe permitir registrar un código de barras opcional por producto. |
| RF-12 | El sistema debe validar que un código de barras no se repita entre productos activos. |
| RF-13 | El sistema debe permitir buscar productos por nombre, código de barras, categoría, marca o presentación. |
| RF-14 | El sistema debe almacenar precio de venta base y costo estimado. |
| RF-15 | El sistema debe permitir configurar stock mínimo e ideal por producto. |
| RF-16 | El sistema debe permitir asociar un proveedor habitual a un producto. |
| RF-17 | El sistema debe conservar historial relevante aunque un producto sea desactivado. |
| RF-18 | El sistema debe permitir consultar rápidamente precio y stock disponible de un producto. |

## Requisitos de proveedores

| ID | Requisito |
|---|---|
| RF-19 | El sistema debe permitir registrar proveedores. |
| RF-20 | El sistema debe permitir editar, consultar y desactivar proveedores. |
| RF-21 | El sistema debe almacenar datos de contacto y observaciones comerciales del proveedor. |
| RF-22 | El sistema debe permitir asociar productos con uno o más proveedores. |
| RF-23 | El sistema debe permitir consultar productos abastecidos por un proveedor. |
| RF-23.1 | El sistema debe permitir registrar el método habitual por el cual un proveedor envía listas de precios. |
| RF-23.2 | El sistema debe permitir mapear un producto interno con el nombre, código y presentación usados por cada proveedor. |
| RF-23.3 | El sistema debe permitir definir proveedor habitual y proveedores alternativos para un producto. |
| RF-23.4 | El sistema debe permitir comparar costos vigentes de un producto entre distintos proveedores. |

## Requisitos de stock y vencimientos

| ID | Requisito |
|---|---|
| RF-24 | El sistema debe registrar ingresos de mercadería al stock. |
| RF-25 | El sistema debe manejar stock por lote o vencimiento cuando el producto lo requiera. |
| RF-26 | El sistema debe mostrar stock total por producto. |
| RF-27 | El sistema debe mostrar detalle de stock por lote y fecha de vencimiento. |
| RF-28 | El sistema debe registrar movimientos de stock ante toda variación relevante. |
| RF-29 | El sistema debe permitir ajustes positivos y negativos de stock con motivo obligatorio. |
| RF-30 | El sistema debe permitir registrar mermas, roturas o retiros por vencimiento. |
| RF-31 | El sistema debe impedir ventas o egresos que excedan stock disponible, salvo permiso excepcional. |
| RF-32 | El sistema debe descontar stock siguiendo criterio FEFO para productos con vencimiento. |
| RF-33 | El sistema debe identificar productos con stock bajo según stock mínimo. |
| RF-34 | El sistema debe identificar productos próximos a vencer según umbral configurable. |
| RF-35 | El sistema debe permitir consultar historial de movimientos de stock por producto. |
| RF-36 | El sistema debe permitir realizar inventario físico y registrar diferencias. |

## Requisitos de venta mostrador simplificada

| ID | Requisito |
|---|---|
| RF-37 | El sistema debe permitir iniciar una venta mostrador en estado borrador. |
| RF-38 | El sistema debe permitir escanear productos mediante lector de código de barras. |
| RF-39 | El sistema debe interpretar el lector de barras como entrada estándar de teclado. |
| RF-40 | El sistema debe buscar automáticamente el producto al recibir un código de barras. |
| RF-41 | El sistema debe permitir buscar productos manualmente si no poseen código de barras. |
| RF-42 | El sistema debe permitir agregar productos al detalle de venta. |
| RF-43 | El sistema debe permitir modificar la cantidad de un producto antes de confirmar la venta. |
| RF-44 | El sistema debe validar que la cantidad vendida sea mayor que cero. |
| RF-45 | El sistema debe recalcular subtotales y total ante cambios de cantidad o precio. |
| RF-46 | El sistema debe permitir quitar productos de una venta en estado borrador. |
| RF-47 | El sistema debe confirmar la venta solo si se cumplen las validaciones de stock, precio y permisos. |
| RF-48 | El sistema debe descontar stock automáticamente al confirmar una venta. |
| RF-49 | El sistema debe generar automáticamente un ingreso de caja al confirmar una venta. |
| RF-50 | El sistema debe guardar la venta con estado confirmada. |
| RF-51 | El sistema debe permitir anular una venta mediante operación controlada y auditable. |
| RF-52 | El sistema debe permitir consultar ventas por fecha, usuario, turno o estado. |

## Requisitos de precio aplicado en venta

| ID | Requisito |
|---|---|
| RF-53 | El sistema debe guardar en el detalle de venta el precio base vigente al momento de vender. |
| RF-54 | El sistema debe guardar el precio aplicado final en cada línea de venta. |
| RF-55 | El sistema debe permitir modificar precio unitario en venta solo con permiso o regla configurada. |
| RF-56 | El sistema debe exigir motivo cuando el precio aplicado difiera del precio base. |
| RF-57 | El sistema debe auditar toda modificación manual de precio en venta. |
| RF-58 | El sistema debe evitar que cambios futuros del producto alteren ventas históricas. |

## Requisitos de ofertas temporales

| ID | Requisito |
|---|---|
| RF-59 | El sistema debe permitir crear ofertas temporales asociadas a productos. |
| RF-60 | El sistema debe permitir definir fecha de inicio y fecha de fin de una oferta. |
| RF-61 | El sistema debe permitir ofertas por porcentaje de descuento o precio fijo. |
| RF-62 | El sistema debe permitir activar o desactivar ofertas. |
| RF-63 | El sistema debe detectar ofertas vigentes al agregar un producto a la venta. |
| RF-64 | El sistema debe aplicar o sugerir el precio promocional según la regla definida. |
| RF-65 | El sistema debe registrar la oferta aplicada en el detalle de venta. |
| RF-66 | El sistema debe impedir la aplicación automática de ofertas vencidas o inactivas. |
| RF-67 | El sistema debe auditar creación, edición y desactivación de ofertas. |

## Requisitos de consumo interno

| ID | Requisito |
|---|---|
| RF-68 | El sistema debe permitir registrar consumo interno de productos. |
| RF-69 | El sistema debe permitir seleccionar razón de consumo interno. |
| RF-70 | El sistema debe exigir producto, cantidad, usuario y fecha para cada consumo. |
| RF-71 | El sistema debe descontar stock por FEFO al confirmar un consumo interno. |
| RF-72 | El sistema no debe generar ingreso de caja por consumo interno. |
| RF-73 | El sistema debe permitir configurar si el consumo interno requiere aprobación. |
| RF-74 | El sistema debe permitir consultar consumos internos por usuario, fecha o producto. |
| RF-75 | El sistema debe distinguir consumo interno de venta, merma y vencimiento. |

## Requisitos de caja y turnos

| ID | Requisito |
|---|---|
| RF-76 | El sistema debe permitir abrir caja o turno con saldo inicial. |
| RF-77 | El sistema debe registrar ingresos automáticos por ventas confirmadas. |
| RF-78 | El sistema debe permitir registrar ingresos manuales con concepto. |
| RF-79 | El sistema debe permitir registrar egresos manuales con concepto. |
| RF-80 | El sistema debe relacionar cada ingreso automático con la venta correspondiente. |
| RF-81 | El sistema debe permitir consultar movimientos de caja por fecha, usuario y tipo. |
| RF-82 | El sistema debe permitir cerrar turno con resumen operativo. |
| RF-83 | El sistema debe permitir realizar cierre diario de caja. |
| RF-84 | El sistema debe calcular saldo esperado, saldo contado y diferencia. |
| RF-85 | El sistema debe restringir modificaciones sobre cierres confirmados a usuarios administradores. |

## Requisitos de listas de precios de proveedor

| ID | Requisito |
|---|---|
| RF-86 | El sistema debe permitir cargar listas de precios de proveedor desde archivos Excel. |
| RF-87 | El sistema debe permitir cargar listas de precios copiando texto desde WhatsApp. |
| RF-88 | El sistema debe permitir cargar precios de proveedor manualmente. |
| RF-89 | El sistema debe registrar proveedor, fecha de lista, usuario de carga y método de carga. |
| RF-90 | El sistema debe normalizar los ítems de una lista para su revisión. |
| RF-91 | El sistema debe intentar asociar cada ítem de lista con un producto interno. |
| RF-92 | El sistema debe clasificar ítems como reconocido, posible coincidencia, no reconocido, nuevo producto o ignorado. |
| RF-93 | El sistema debe permitir resolver manualmente ítems no reconocidos o con coincidencia dudosa. |
| RF-94 | El sistema debe mostrar costo anterior, costo nuevo y diferencia porcentual antes de aplicar cambios. |
| RF-95 | El sistema debe permitir descartar una lista de precios sin aplicarla. |
| RF-96 | El sistema debe auditar la carga, revisión, aplicación o descarte de listas de precios. |

## Requisitos de actualización asistida de precios

| ID | Requisito |
|---|---|
| RF-97 | El sistema debe distinguir costo proveedor de precio de venta. |
| RF-98 | El sistema debe registrar historial de costo por proveedor. |
| RF-99 | El sistema debe permitir definir reglas de margen por categoría o producto. |
| RF-100 | El sistema debe permitir definir reglas de redondeo para precios sugeridos. |
| RF-101 | El sistema debe calcular precio de venta sugerido a partir del costo, margen y redondeo. |
| RF-102 | El sistema debe permitir aplicar solo costos sin modificar precios de venta. |
| RF-103 | El sistema debe permitir aplicar precios de venta seleccionados con aprobación de la dueña. |
| RF-104 | El sistema debe registrar historial de precio de venta con origen, motivo y usuario. |
| RF-105 | El sistema debe marcar productos con etiqueta pendiente cuando cambie su precio de venta. |

## Requisitos de precios, etiquetas e impresión

| ID | Requisito |
|---|---|
| RF-106 | El sistema debe permitir actualizar precios de productos. |
| RF-107 | El sistema debe registrar historial de cambios de precio relevantes. |
| RF-108 | El sistema debe permitir generar etiquetas de precio imprimibles. |
| RF-109 | El sistema debe permitir generar listados de precios imprimibles. |
| RF-110 | El sistema debe permitir filtrar etiquetas por categoría, proveedor, oferta o productos modificados. |
| RF-111 | El sistema debe permitir consultar etiquetas pendientes. |
| RF-112 | El sistema debe permitir marcar etiquetas pendientes como impresas o resueltas. |

## Requisitos de pedidos y recepción de mercadería

| ID | Requisito |
|---|---|
| RF-113 | El sistema debe permitir consultar productos por debajo del stock mínimo. |
| RF-114 | El sistema debe calcular cantidad sugerida de reposición como diferencia entre stock ideal y stock actual. |
| RF-115 | El sistema debe agrupar sugerencias de reposición por proveedor habitual o proveedor con mejor costo reciente. |
| RF-116 | El sistema debe permitir crear pedidos a proveedor en estado borrador. |
| RF-117 | El sistema debe permitir cambiar estado de pedido a enviado, recibido parcial, recibido o cancelado. |
| RF-118 | El sistema debe permitir registrar recepción total o parcial de mercadería. |
| RF-119 | El sistema debe permitir cargar vencimientos/lotes al recibir mercadería. |
| RF-120 | El sistema debe generar movimientos de stock `INGRESO_COMPRA` al confirmar una recepción. |
| RF-121 | El sistema debe actualizar costo proveedor si la recepción confirma un costo diferente. |

## Requisitos de importación y exportación

| ID | Requisito |
|---|---|
| RF-122 | El sistema debe permitir importar datos desde archivos Excel. |
| RF-123 | El sistema debe validar estructura, columnas y tipos de datos antes de persistir. |
| RF-124 | El sistema debe mostrar errores de importación por fila o campo. |
| RF-125 | El sistema debe requerir confirmación antes de aplicar una importación masiva. |
| RF-126 | El sistema debe permitir exportar productos, stock, proveedores, ventas, caja, listas de precios y reportes. |
| RF-127 | El sistema debe auditar importaciones y exportaciones relevantes. |
| RF-128 | El sistema no debe incluir lectura automática desde PDF, imágenes, fotos, OCR, audio o catálogos web en el alcance inicial. |

## Requisitos de reportes, métricas y alertas

| ID | Requisito |
|---|---|
| RF-129 | El sistema debe generar reporte de stock actual. |
| RF-130 | El sistema debe generar reporte de próximos vencimientos. |
| RF-131 | El sistema debe generar reporte de ventas por día o turno. |
| RF-132 | El sistema debe generar reporte de movimientos de caja. |
| RF-133 | El sistema debe generar reporte de consumo interno y mermas. |
| RF-134 | El sistema debe generar reportes de cambios de precio. |
| RF-135 | El sistema debe generar reportes de listas importadas y estado de revisión. |
| RF-136 | El sistema debe generar reportes de comparación de costos por proveedor. |
| RF-137 | El sistema debe generar reportes de etiquetas pendientes. |
| RF-138 | El sistema debe mostrar métricas operativas en el panel de administración. |
| RF-139 | El sistema debe mostrar tareas o alertas operativas en el panel de empleado. |
| RF-140 | El sistema debe notificar stock bajo. |
| RF-141 | El sistema debe notificar vencimientos próximos. |
| RF-142 | El sistema debe notificar cierres de caja pendientes. |
| RF-143 | El sistema debe notificar listas de precios o cambios pendientes de revisión. |
| RF-144 | El sistema debe evitar alertas duplicadas cuando la condición base no cambió. |

## Requisitos de interfaz, API y despliegue

| ID | Requisito |
|---|---|
| RF-145 | El sistema debe ser responsive y priorizar uso mobile-first. |
| RF-146 | El sistema debe ofrecer vista diferenciada para administradora y empleado. |
| RF-147 | El sistema debe ofrecer accesos rápidos a nueva venta, consulta de producto y cierre de turno. |
| RF-148 | El sistema debe exponer una API REST para consumo del frontend. |
| RF-149 | El sistema debe validar en backend toda entrada recibida desde el frontend. |
| RF-150 | El sistema debe documentar la API mediante OpenAPI o Swagger. |
| RF-151 | El sistema debe estar preparado para despliegue en nube con Nginx como reverse proxy. |

## Matriz de trazabilidad resumida

| Rango | Módulo | Casos de uso principales | Entidades principales |
|---|---|---|---|
| RF-01 a RF-08 | Seguridad | CU-01 | Usuario, Rol, Permiso, Auditoria |
| RF-09 a RF-18 | Productos | CU-02, CU-03 | Producto, Categoria, Marca, HistorialPrecio |
| RF-19 a RF-23.4 | Proveedores | CU-04 | Proveedor, ProductoProveedor |
| RF-24 a RF-36 | Stock | CU-05, CU-06, CU-07 | LoteStock, MovimientoStock, InventarioFisico |
| RF-37 a RF-58 | Ventas | CU-08, CU-09, CU-10 | Venta, DetalleVenta, MovimientoCaja |
| RF-59 a RF-67 | Ofertas | CU-11 | OfertaTemporal, DetalleVenta |
| RF-68 a RF-75 | Consumo interno | CU-12 | ConsumoInterno, DetalleConsumoInterno |
| RF-76 a RF-85 | Caja | CU-13, CU-14 | TurnoCaja, MovimientoCaja, CierreCaja |
| RF-86 a RF-96 | Listas de precios | CU-16 | ListaPrecioProveedor, ItemListaPrecioProveedor |
| RF-97 a RF-105 | Actualización asistida | CU-17 | HistorialCostoProveedor, ReglaPrecio, HistorialPrecioVenta |
| RF-106 a RF-112 | Precios y etiquetas | CU-18 | HistorialPrecioVenta, EtiquetaPrecio |
| RF-113 a RF-121 | Pedidos y recepción | CU-19, CU-20 | PedidoProveedor, DetallePedidoProveedor, RecepcionMercaderia |
| RF-122 a RF-128 | Importación/exportación | CU-21 | Importacion, Exportacion, ErrorImportacion |
| RF-129 a RF-144 | Reportes y alertas | CU-22, CU-23 | AlertaOperativa, Reporte |
| RF-145 a RF-151 | Interfaz/API | CU-24 | DTOs, Vista, EventoEntrada |

## Observación

> [!tip]
> Esta lista puede usarse como base para historias de usuario, criterios de aceptación, casos de prueba y matriz de trazabilidad del informe final.
