---
title: Modelo de datos conceptual
aliases:
  - Entidades del dominio
  - Modelo conceptual
  - Modelo de datos Lembas
tags:
  - tpf
  - modelo-de-datos
  - dominio
  - entidades
  - postgresql
cssclasses:
  - wide-page
---

# Modelo de datos conceptual

> [!abstract]
> Modelo conceptual actualizado para Lembas. Representa las entidades principales necesarias para productos, proveedores, listas de precios, actualización asistida, stock por vencimiento, venta mostrador simplificada, ofertas, consumo interno, pedidos, recepción, caja, reportes y auditoría. No reemplaza el DER físico final, pero sirve como base de análisis y diseño.

## Criterios de modelado

El modelo debe permitir:

- conservar trazabilidad histórica;
- evitar eliminación física de datos transaccionales;
- representar stock por lotes y vencimientos;
- mapear productos internos contra productos de proveedor;
- registrar listas de precios por Excel, WhatsApp o carga manual;
- comparar costos nuevos contra costos anteriores;
- aplicar precios de venta solo con aprobación;
- diferenciar venta, consumo interno, merma y ajuste;
- guardar precio histórico aplicado en cada venta;
- relacionar ventas confirmadas con caja;
- auditar acciones críticas;
- consultar reportes operativos con filtros.

## Entidades principales

```text
Usuario
Rol
Permiso

Producto
Categoria
Marca
Presentacion
CodigoBarra
Proveedor
ProductoProveedor
ListaPrecioProveedor
ItemListaPrecioProveedor
HistorialCostoProveedor
ReglaPrecio
HistorialPrecioVenta
EtiquetaPrecio

LoteStock
MovimientoStock
InventarioFisico
DetalleInventarioFisico

Venta
DetalleVenta
OfertaTemporal

ConsumoInterno
DetalleConsumoInterno

TurnoCaja
MovimientoCaja
CierreCaja

PedidoProveedor
DetallePedidoProveedor
RecepcionMercaderia
DetalleRecepcionMercaderia

Importacion
ErrorImportacion
Exportacion

AlertaOperativa
Auditoria
```

---

# Seguridad y usuarios

## Usuario

Representa a una persona con acceso al sistema.

Atributos sugeridos:

- id;
- nombre;
- apellido;
- email o usuario;
- passwordHash;
- rol;
- estado;
- fechaAlta;
- ultimoAcceso;
- creadoPor;
- actualizadoPor.

## Rol

Define el conjunto principal de permisos.

Valores iniciales:

- `ADMINISTRADORA`;
- `EMPLEADO`.

## Permiso

Representa permisos específicos para operaciones sensibles.

Ejemplos:

- modificar precio en venta;
- anular venta;
- ajustar stock;
- cerrar caja;
- ver reportes financieros;
- gestionar usuarios.

---

# Catálogo

## Producto

Representa un producto vendido o administrado por la dietética.

Atributos sugeridos:

- id;
- codigoInterno;
- codigoBarras;
- nombre;
- descripcion;
- categoria;
- marca;
- presentacion;
- precioVentaBase;
- costoEstimado;
- stockMinimo;
- stockIdeal;
- proveedorHabitual;
- requiereVencimiento;
- etiquetaPendiente;
- activo;
- observaciones.

Reglas relevantes:

- el código de barras es opcional;
- el código de barras no debe repetirse entre productos activos;
- el producto inactivo no debe venderse;
- las ventas históricas no dependen del precio actual del producto.

## Categoria

Agrupa productos para búsqueda, reportes y organización.

Atributos:

- id;
- nombre;
- descripcion;
- activa.

## Marca

Permite clasificar productos por fabricante o marca comercial.

Atributos:

- id;
- nombre;
- descripcion;
- activa.

## Proveedor

Representa una entidad que abastece productos.

Atributos sugeridos:

- id;
- razonSocial;
- cuit;
- contacto;
- telefono;
- email;
- direccion;
- observaciones;
- activo.

## ProductoProveedor

Tabla de relación entre productos internos y la forma en que cada proveedor los identifica.

Atributos:

- id;
- producto;
- proveedor;
- codigoProveedor;
- nombreProveedor;
- presentacionProveedor;
- ultimoCosto;
- fechaUltimaActualizacion;
- esHabitual;
- activo;
- observaciones.

## ListaPrecioProveedor

Representa una lista cargada desde Excel, texto copiado desde WhatsApp o carga manual.

Atributos:

- id;
- proveedor;
- metodoCarga;
- nombreArchivoOriginal;
- textoOriginal;
- fechaLista;
- fechaCarga;
- usuarioCarga;
- estado;
- observaciones.

Estados posibles:

- `CARGADA`;
- `PROCESADA`;
- `EN_REVISION`;
- `APLICADA`;
- `DESCARTADA`;
- `CON_ERRORES`.

## ItemListaPrecioProveedor

Representa una línea detectada dentro de una lista de proveedor.

Atributos:

- id;
- listaPrecioProveedor;
- productoProveedor;
- productoInternoSugerido;
- nombreDetectado;
- presentacionDetectada;
- codigoDetectado;
- costoNuevo;
- costoAnterior;
- diferenciaPorcentual;
- stockProveedor;
- estadoReconocimiento;
- accionSeleccionada;
- observaciones.

Estados de reconocimiento:

- `RECONOCIDO`;
- `POSIBLE_COINCIDENCIA`;
- `NO_RECONOCIDO`;
- `NUEVO_PRODUCTO`;
- `IGNORADO`.

## HistorialCostoProveedor

Guarda la evolución del costo de compra por proveedor.

Atributos:

- id;
- productoProveedor;
- costo;
- fechaVigencia;
- listaPrecioProveedor;
- usuario;
- createdAt.

## ReglaPrecio

Define criterios para sugerir precio de venta.

Atributos:

- id;
- categoria;
- producto;
- margenDeseado;
- tipoRedondeo;
- activa.

## HistorialPrecioVenta

Registra cambios del precio de venta.

Atributos:

- id;
- producto;
- precioAnterior;
- precioNuevo;
- motivo;
- origen;
- usuario;
- createdAt.

## HistorialPrecio

> [!note]
> En el modelo actualizado, esta entidad puede implementarse como `HistorialPrecioVenta` para distinguir explícitamente el precio de venta del costo proveedor.

## EtiquetaPrecio

Representa una etiqueta o listado generado para impresión.

Atributos:

- id;
- producto;
- precioImpreso;
- fechaGeneracion;
- usuario;
- formato;
- estado.

---

# Stock

## LoteStock

Representa una cantidad disponible de un producto, asociada a vencimiento cuando corresponda.

Atributos sugeridos:

- id;
- producto;
- cantidadDisponible;
- fechaVencimiento;
- loteProveedor;
- fechaIngreso;
- proveedor;
- observaciones;
- estado.

## MovimientoStock

Representa cualquier entrada o salida de stock.

Atributos sugeridos:

- id;
- producto;
- loteStock;
- tipoMovimiento;
- cantidad;
- motivo;
- usuario;
- fechaHora;
- entidadReferencia;
- referenciaId;
- observaciones.

Tipos posibles:

- `INGRESO_COMPRA`;
- `EGRESO_VENTA`;
- `CONSUMO_INTERNO`;
- `MERMA`;
- `VENCIMIENTO`;
- `AJUSTE_POSITIVO`;
- `AJUSTE_NEGATIVO`;
- `DEVOLUCION`.

## InventarioFisico

Representa un conteo físico de stock.

Atributos:

- id;
- fechaHora;
- usuario;
- estado;
- observaciones.

## DetalleInventarioFisico

Representa la comparación entre stock teórico y conteo real.

Atributos:

- id;
- inventarioFisico;
- producto;
- loteStock;
- cantidadTeorica;
- cantidadContada;
- diferencia;
- observaciones.

---

# Ventas

## Venta

Representa una venta mostrador simplificada.

Atributos sugeridos:

- id;
- numero;
- fechaHora;
- usuario;
- turnoCaja;
- total;
- estado;
- observaciones;
- movimientoCaja;
- motivoAnulacion.

Estados posibles:

- `BORRADOR`;
- `CONFIRMADA`;
- `ANULADA`.

## DetalleVenta

Representa cada producto dentro de una venta.

Atributos sugeridos:

- id;
- venta;
- producto;
- cantidad;
- precioBaseHistorico;
- precioAplicado;
- descuentoAplicado;
- subtotal;
- ofertaTemporal;
- motivoCambioPrecio;
- usuarioAutorizadorPrecio.

Punto clave:

> [!important]
> El detalle de venta debe guardar el precio aplicado en ese momento. No debe depender del precio actual del producto para reconstruir una venta histórica.

---

# Ofertas

## OfertaTemporal

Representa una promoción temporal asociada a un producto.

Atributos sugeridos:

- id;
- producto;
- nombre;
- descripcion;
- tipoOferta;
- porcentajeDescuento;
- precioPromocional;
- fechaInicio;
- fechaFin;
- activa;
- prioridad;
- usuarioCreador;
- observaciones.

Tipos posibles:

- `PORCENTAJE`;
- `PRECIO_FIJO`;
- `VENCIMIENTO_PROXIMO`;
- `LIQUIDACION`.

---

# Consumo interno

## ConsumoInterno

Representa un registro de consumo por empleado o dueña.

Atributos sugeridos:

- id;
- usuarioSolicitante;
- usuarioAprobador;
- fechaHora;
- razon;
- estado;
- observaciones.

Estados posibles:

- `BORRADOR`;
- `PENDIENTE_APROBACION`;
- `APROBADO`;
- `RECHAZADO`;
- `CONFIRMADO`.

## DetalleConsumoInterno

Representa cada producto consumido internamente.

Atributos:

- id;
- consumoInterno;
- producto;
- loteStock;
- cantidad;
- observaciones.

Razones posibles:

- `CONSUMO_EMPLEADO`;
- `CONSUMO_DUENA`;
- `DEGUSTACION`;
- `MUESTRA`;
- `CAPACITACION`;
- `OTRO`.

---

# Caja

## TurnoCaja

Representa el período operativo de un usuario o jornada.

Atributos:

- id;
- usuario;
- fechaApertura;
- fechaCierre;
- saldoInicial;
- estado;
- observacionesApertura;
- observacionesCierre.

## MovimientoCaja

Representa un ingreso o egreso de dinero.

Atributos sugeridos:

- id;
- turnoCaja;
- tipoMovimiento;
- concepto;
- monto;
- fechaHora;
- usuario;
- venta;
- observaciones.

Tipos posibles:

- `INGRESO_VENTA`;
- `INGRESO_MANUAL`;
- `EGRESO_MANUAL`;
- `RETIRO`;
- `GASTO_OPERATIVO`;
- `AJUSTE`.

## CierreCaja

Representa el cierre diario o de turno.

Atributos:

- id;
- turnoCaja;
- fechaHora;
- saldoInicial;
- totalIngresos;
- totalEgresos;
- saldoEsperado;
- saldoContado;
- diferencia;
- usuarioResponsable;
- observaciones;
- estado.

---

# Pedidos y recepción

## PedidoProveedor

Representa un pedido de reposición a un proveedor.

Atributos:

- id;
- proveedor;
- fecha;
- estado;
- usuarioCreador;
- observaciones.

Estados posibles:

- `BORRADOR`;
- `ENVIADO`;
- `RECIBIDO_PARCIAL`;
- `RECIBIDO`;
- `CANCELADO`.

## DetallePedidoProveedor

Representa un producto solicitado dentro de un pedido.

Atributos:

- id;
- pedidoProveedor;
- producto;
- productoProveedor;
- cantidadSolicitada;
- cantidadRecibida;
- costoEsperado;
- observaciones.

## RecepcionMercaderia

Representa una recepción total o parcial de mercadería.

Atributos:

- id;
- pedidoProveedor;
- proveedor;
- fechaRecepcion;
- usuario;
- estado;
- observaciones.

## DetalleRecepcionMercaderia

Representa cada producto recibido.

Atributos:

- id;
- recepcionMercaderia;
- producto;
- loteStock;
- cantidadRecibida;
- fechaVencimiento;
- costoRecibido;
- observaciones.

---

# Importaciones, reportes y auditoría

## Importacion

Atributos:

- id;
- tipo;
- archivoNombre;
- usuario;
- fechaHora;
- estado;
- cantidadFilas;
- cantidadErrores.

## ErrorImportacion

Atributos:

- id;
- importacion;
- fila;
- campo;
- mensaje;
- valorRecibido.

## Exportacion

Atributos:

- id;
- tipo;
- usuario;
- fechaHora;
- filtros;
- formato;
- estado.

## AlertaOperativa

Atributos:

- id;
- tipo;
- severidad;
- producto;
- mensaje;
- fechaGeneracion;
- estado;
- fechaResolucion;
- usuarioResolucion.

## Auditoria

Atributos:

- id;
- usuario;
- accion;
- entidad;
- entidadId;
- fechaHora;
- detalle;
- valorAnterior;
- valorNuevo;
- ipOrigen.

---

# Relaciones principales

- Un rol tiene muchos usuarios.
- Un usuario registra ventas, movimientos de stock, movimientos de caja, consumos y auditoría.
- Un producto pertenece a una categoría y puede tener una marca.
- Un producto puede tener muchos lotes de stock.
- Un producto puede tener muchos movimientos de stock.
- Un producto puede estar asociado a varios proveedores mediante ProductoProveedor.
- Un proveedor puede tener muchas listas de precios.
- Una lista de precios contiene muchos ítems de lista.
- Un ProductoProveedor puede tener muchos registros de historial de costo.
- Un producto puede tener reglas o historial de precio de venta.
- Un producto puede tener muchas ofertas temporales.
- Una venta tiene muchos detalles de venta.
- Una venta confirmada genera movimientos de stock y un movimiento de caja.
- Un consumo interno tiene muchos detalles y genera movimientos de stock.
- Un turno de caja contiene muchos movimientos de caja.
- Un cierre de caja resume un turno o jornada.
- Una alerta puede estar asociada a producto, stock, caja o importación.
- La auditoría puede referenciar cualquier entidad crítica.

## Diagrama conceptual

```mermaid
erDiagram
    ROL ||--o{ USUARIO : asigna
    USUARIO ||--o{ VENTA : registra
    USUARIO ||--o{ MOVIMIENTO_STOCK : registra
    USUARIO ||--o{ MOVIMIENTO_CAJA : registra
    USUARIO ||--o{ CONSUMO_INTERNO : solicita
    USUARIO ||--o{ AUDITORIA : genera

    CATEGORIA ||--o{ PRODUCTO : clasifica
    MARCA ||--o{ PRODUCTO : identifica
    PRODUCTO ||--o{ LOTE_STOCK : posee
    PRODUCTO ||--o{ MOVIMIENTO_STOCK : genera
    PRODUCTO ||--o{ DETALLE_VENTA : vendido_en
    PRODUCTO ||--o{ OFERTA_TEMPORAL : promociona
    PRODUCTO ||--o{ HISTORIAL_PRECIO : cambia_precio
    PRODUCTO }o--o{ PROVEEDOR : abastecido_por
    PROVEEDOR ||--o{ LISTA_PRECIO_PROVEEDOR : envia
    LISTA_PRECIO_PROVEEDOR ||--o{ ITEM_LISTA_PRECIO_PROVEEDOR : contiene
    PRODUCTO_PROVEEDOR ||--o{ HISTORIAL_COSTO_PROVEEDOR : registra
    PRODUCTO ||--o{ HISTORIAL_PRECIO_VENTA : cambia
    PROVEEDOR ||--o{ PEDIDO_PROVEEDOR : recibe
    PEDIDO_PROVEEDOR ||--o{ DETALLE_PEDIDO_PROVEEDOR : contiene
    PEDIDO_PROVEEDOR ||--o{ RECEPCION_MERCADERIA : origina

    VENTA ||--o{ DETALLE_VENTA : contiene
    OFERTA_TEMPORAL ||--o{ DETALLE_VENTA : aplica
    VENTA ||--o| MOVIMIENTO_CAJA : genera

    CONSUMO_INTERNO ||--o{ DETALLE_CONSUMO_INTERNO : contiene
    LOTE_STOCK ||--o{ MOVIMIENTO_STOCK : afecta

    TURNO_CAJA ||--o{ MOVIMIENTO_CAJA : contiene
    TURNO_CAJA ||--o| CIERRE_CAJA : cierra

    PRODUCTO ||--o{ ALERTA_OPERATIVA : genera
```

## Observación técnica

Este modelo puede implementarse con JPA/Hibernate usando entidades para persistencia y DTOs para la API. Las operaciones críticas, como confirmar venta o consumo interno, deben ejecutarse en servicios transaccionales para mantener consistencia entre stock, caja y auditoría.
