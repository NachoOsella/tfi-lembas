---
title: TPF Dietética Lembas - Documento técnico actualizado
aliases:
  - Lembas Gestión Interna
  - Sistema de gestión interna para dietética
  - TPF Lembas
  - Gestión interna con stock, caja, proveedores y venta simplificada
  - Sistema con código de barras para dietética
created: 2026-04-23
tags:
  - tpf
  - dietetica
  - spring-boot
  - angular
  - postgresql
  - gestion-interna
  - stock
  - vencimientos
  - caja
  - codigo-de-barras
  - venta-simplificada
  - proveedores
  - precios
  - ofertas
  - auditoria
  - roles
cssclasses:
  - wide-page
---

# TPF Dietética Lembas

> [!abstract]
> Documento técnico central del Trabajo Práctico Final. Define el alcance funcional, roles, procesos de negocio, reglas, modelo conceptual, módulos, decisiones técnicas y posibles flujos de implementación del sistema **Lembas**, una plataforma web de gestión interna para una dietética de una sola sucursal.

## Nombre tentativo

**Lembas: sistema web de gestión interna, stock, proveedores y venta mostrador simplificada para una dietética**

## Propósito del sistema

Desarrollar una **plataforma web de gestión interna** para una dietética de una sola sucursal, orientada a reemplazar el uso centralizado de Excel, anotaciones manuales y registros dispersos por una aplicación propia con:

- persistencia en base de datos;
- trazabilidad operativa;
- control de stock por lote y vencimiento;
- gestión de proveedores y listas de precios;
- actualización asistida de precios;
- ofertas temporales;
- venta mostrador simplificada con lector de código de barras;
- caja interna y cierre de turno/día;
- control de consumo interno, mermas y ajustes;
- roles diferenciados entre dueña/administradora y empleados.

El sistema busca resolver procesos reales del negocio sin transformarse en un POS fiscal completo ni en una solución contable avanzada.

---

# Referencias visuales

Las siguientes imágenes son mockups de referencia. Están enlazadas como archivos externos, sin adjuntarse dentro de este documento.

- [Pantalla de login](sandbox:/mnt/data/natural_wellness_store_app_login_page.png)
- [Home de administración](sandbox:/mnt/data/modern_green_themed_retail_dashboard_ui.png)
- [Home de empleado refinada](sandbox:/mnt/data/botanical_themed_dashboard_ui_design.png)

> [!note]
> La primera versión de la pantalla de empleado fue descartada por redundancia visual y exceso de información operativa repetida.

---

# Contexto del negocio

La dietética opera como un comercio minorista de una sola sucursal. Maneja productos con características variadas:

- productos empaquetados con código de barras;
- productos sin código de barras;
- productos con vencimiento;
- productos de diferentes proveedores;
- productos con cambios frecuentes de costo;
- productos que pueden tener ofertas temporales;
- productos que pueden consumirse internamente por empleados o dueña;
- productos que pueden tener merma, vencimiento o ajustes de inventario.

Actualmente, los procesos pueden depender de Excel, WhatsApp, listas enviadas por proveedores, controles manuales y memoria operativa del negocio. Esto genera riesgo de inconsistencias entre stock físico, stock registrado, precios exhibidos, precios actualizados, caja y movimientos internos.

---

# Problema a resolver

El sistema busca resolver las siguientes dificultades:

- dependencia excesiva de Excel;
- ausencia de trazabilidad sobre cambios de stock y precios;
- dificultad para controlar productos próximos a vencer;
- actualización manual y dispersa de precios;
- varios proveedores con formatos distintos de listas de precios;
- falta de comparación clara entre costos anteriores y costos nuevos;
- imposibilidad de saber rápidamente qué proveedor conviene para reponer;
- ventas mostrador que no descuentan stock automáticamente;
- consumos internos que reducen stock sin registro formal;
- mermas o vencimientos que no quedan justificadas;
- caja del turno poco conectada con las ventas registradas;
- empleados con acceso potencial a información que no necesitan;
- falta de reportes operativos confiables.

---

# Solución propuesta

Se propone desarrollar un sistema web interno que centralice los procesos principales de la dietética:

1. administración de productos;
2. stock por lote y vencimiento;
3. venta mostrador simplificada;
4. caja interna;
5. consumo interno;
6. mermas y vencimientos;
7. ofertas temporales;
8. proveedores múltiples;
9. importación de listas de precios por Excel, texto de WhatsApp o carga manual;
10. comparación de costos y actualización asistida de precios;
11. reposición sugerida;
12. etiquetas imprimibles;
13. reportes operativos;
14. auditoría de acciones críticas.

El sistema debe ser suficientemente completo para demostrar modelado de dominio, arquitectura, transacciones, reglas de negocio, seguridad por roles y trazabilidad, pero sin sumar complejidad fiscal o contable innecesaria.

---

# Fuera de alcance

La primera versión no incluirá:

- facturación fiscal;
- integración con AFIP;
- emisión de comprobantes legales;
- pasarelas de pago;
- integración automática con tarjetas o Mercado Pago;
- e-commerce;
- multi-sucursal;
- cuenta corriente de clientes;
- CRM avanzado;
- contabilidad completa;
- lectura automática desde PDF;
- lectura automática desde imágenes o fotos;
- OCR;
- predicción avanzada de demanda;
- inteligencia artificial generativa.

> [!warning]
> PDF, imágenes y OCR quedan explícitamente fuera de alcance porque agregan complejidad técnica alta y no son necesarios para validar el núcleo del sistema.

---

# Roles del sistema

El sistema se diseñará con control de acceso basado en roles. La información visible y las acciones permitidas deben cambiar según el usuario.

## Rol: Administradora / Dueña

Usuario principal del negocio. Tiene acceso a información sensible, configuración y decisiones comerciales.

### Puede realizar

- Gestionar usuarios y roles.
- Crear, editar, activar y desactivar productos.
- Gestionar categorías, marcas y presentaciones.
- Gestionar proveedores.
- Asociar productos internos con productos de proveedores.
- Importar listas de precios.
- Revisar y aprobar cambios de costo.
- Actualizar precios de venta.
- Configurar reglas de margen o redondeo.
- Crear y editar ofertas temporales.
- Configurar stock mínimo e ideal.
- Registrar ingresos de mercadería.
- Ajustar stock con motivo.
- Registrar ventas.
- Anular ventas.
- Registrar consumo interno.
- Registrar mermas.
- Registrar movimientos manuales de caja.
- Realizar cierre diario.
- Consultar reportes.
- Exportar información.
- Imprimir etiquetas.
- Consultar auditoría.

### Puede ver

- Ventas del día.
- Caja actual.
- Productos con stock bajo.
- Productos próximos a vencer.
- Reposición sugerida.
- Proveedores y costos.
- Comparativas de precios.
- Últimas ventas.
- Reportes generales.
- Movimientos de caja.
- Auditoría.

## Rol: Empleado

Usuario operativo. Debe poder trabajar en el local sin acceder a información estratégica innecesaria.

### Puede realizar

- Registrar ventas mostrador simplificadas.
- Escanear productos por código de barras.
- Buscar productos manualmente.
- Consultar precio de venta y stock disponible.
- Modificar cantidad de un producto dentro de una venta.
- Aplicar ofertas temporales vigentes.
- Modificar precio en venta solo si tiene permiso y motivo.
- Registrar consumo interno autorizado.
- Registrar mermas simples si tiene permiso.
- Consultar productos próximos a vencer.
- Consultar productos con stock bajo para avisar.
- Imprimir etiquetas si tiene permiso.
- Cerrar su turno o dejar cierre pendiente.

### Puede ver

- Vista operativa de inicio.
- Ventas del propio turno en cantidad.
- Tareas prioritarias.
- Productos a revisar.
- Últimas ventas del turno.
- Estado de caja del turno.
- Productos próximos a vencer.
- Acceso a nueva venta.
- Consulta de producto, precio y stock.

### No debería ver por defecto

- Reportes globales.
- Ganancias.
- Márgenes.
- Costos de compra.
- Listas completas de proveedores.
- Configuración global.
- Administración de usuarios.
- Auditoría completa.
- Importaciones masivas.
- Cambios masivos de precios.
- Reposición avanzada.

---

# Matriz inicial de permisos

| Funcionalidad | Admin/Dueña | Empleado |
|---|---:|---:|
| Ver home administrativo | Sí | No |
| Ver home operativo | Sí | Sí |
| Crear producto | Sí | No |
| Editar producto | Sí | No |
| Consultar producto | Sí | Sí |
| Consultar precio venta | Sí | Sí |
| Consultar costo proveedor | Sí | No |
| Registrar venta | Sí | Sí |
| Modificar cantidad en venta | Sí | Sí |
| Modificar precio en venta | Sí | Solo con permiso |
| Anular venta | Sí | Solo con permiso |
| Registrar consumo interno | Sí | Sí, si está habilitado |
| Aprobar consumo interno | Sí | No |
| Registrar merma | Sí | Solo con permiso |
| Crear oferta | Sí | No |
| Importar lista de precios | Sí | No |
| Aprobar cambios de precio | Sí | No |
| Gestionar proveedores | Sí | No |
| Ver reportes generales | Sí | No |
| Cerrar turno propio | Sí | Sí |
| Cerrar caja diaria | Sí | No |
| Ver auditoría | Sí | No |

---

# Alcance funcional resumido

- Gestión de productos, categorías, marcas y presentaciones.
- Productos con código de barras opcional.
- Stock por producto, lote y fecha de vencimiento.
- Venta mostrador simplificada con scanner.
- Búsqueda manual para productos sin código.
- Descuento automático de stock al confirmar venta.
- Registro automático de ingreso en caja por venta.
- Modificación de cantidad en venta.
- Modificación controlada de precio en venta.
- Ofertas temporales.
- Consumo interno de empleados/dueña.
- Mermas, vencimientos y ajustes de inventario.
- Proveedores múltiples por producto.
- Importación de listas de precios por Excel.
- Carga de listas copiadas desde WhatsApp.
- Carga manual de precios de proveedor.
- Mapeo entre productos internos y productos de proveedor.
- Comparación de costos nuevos contra costos anteriores.
- Actualización asistida de precios de venta.
- Reposición sugerida según stock mínimo, ideal y proveedor.
- Pedidos a proveedores como mejora de alcance intermedio.
- Recepción de mercadería con vencimientos.
- Etiquetas imprimibles.
- Caja de turno y cierre diario.
- Reportes operativos.
- Auditoría.

---

# Procesos principales

## 1. Venta mostrador simplificada

### Objetivo

Registrar una venta simple de mostrador, descontar stock y generar ingreso de caja sin implementar un POS fiscal completo.

### Flujo

```text
Escanear producto o buscar manualmente
        ↓
Agregar producto al detalle de venta
        ↓
Modificar cantidad si corresponde
        ↓
Aplicar oferta temporal vigente si existe
        ↓
Modificar precio si el rol tiene permiso y se informa motivo
        ↓
Confirmar venta
        ↓
Descontar stock usando FEFO
        ↓
Registrar ingreso de caja
        ↓
Guardar auditoría
```

### Reglas

- La venta puede estar en estado `BORRADOR`, `CONFIRMADA` o `ANULADA`.
- El stock se descuenta únicamente al confirmar.
- El precio aplicado debe guardarse en el detalle de venta.
- Cambios futuros del precio del producto no deben modificar ventas históricas.
- Si falla el descuento de stock, no debe registrarse el ingreso de caja.
- Si falla el registro de caja, la venta no debería quedar confirmada.
- La confirmación debe ser transaccional.

---

## 2. Modificación de cantidad en venta

Durante una venta, el usuario puede modificar la cantidad de un producto específico.

### Ejemplo

| Producto | Cantidad inicial | Cantidad editada |
|---|---:|---:|
| Avena integral 1kg | 1 | 3 |

### Reglas

- La cantidad debe ser mayor a cero.
- No se debe vender más stock que el disponible, salvo permiso especial.
- El subtotal debe recalcularse automáticamente.
- El stock no se descuenta hasta confirmar la venta.
- Si el mismo producto se escanea varias veces, el sistema puede acumular cantidad en la misma línea.

---

## 3. Modificación de precio en venta

La venta simplificada puede permitir modificar el precio unitario de una línea, pero bajo control.

### Casos válidos

- Etiqueta desactualizada.
- Descuento puntual autorizado.
- Producto con daño menor.
- Promoción verbal autorizada.
- Redondeo excepcional.
- Error detectado en el precio cargado.

### Reglas

- Se debe guardar el precio base y el precio aplicado.
- Si el precio cambia, debe requerir motivo.
- El permiso puede depender del rol.
- El empleado puede tener un límite porcentual configurable.
- Todo cambio manual de precio debe quedar auditado.

### Campos recomendados en `DetalleVenta`

- `productoId`;
- `cantidad`;
- `precioBaseHistorico`;
- `precioAplicado`;
- `descuentoAplicado`;
- `motivoCambioPrecio`;
- `ofertaAplicadaId`;
- `subtotal`.

---

## 4. Ofertas temporales

### Objetivo

Permitir precios promocionales durante un período definido.

### Casos de uso

- Productos próximos a vencer.
- Promoción semanal.
- Liquidación de stock.
- Oferta por temporada.
- Rebaja puntual hasta agotar unidades.

### Tipos de oferta

| Tipo | Descripción | Ejemplo |
|---|---|---|
| `PORCENTAJE` | Aplica un porcentaje de descuento | 15% off |
| `PRECIO_FIJO` | Define un precio promocional | $2.500 |
| `VENCIMIENTO` | Oferta asociada a vencimiento próximo | 20% off por vencer |
| `LIQUIDACION` | Rebaja para salida rápida | Hasta agotar stock |

### Reglas

- Toda oferta debe tener fecha de inicio y fin.
- Una oferta vencida no debe aplicarse automáticamente.
- Una oferta puede estar activa o inactiva.
- Si hay múltiples ofertas activas, debe existir regla de prioridad.
- La venta debe guardar la oferta aplicada y el precio final.
- Crear, editar o desactivar ofertas debe auditarse.

---

## 5. Stock por lote y vencimiento

### Objetivo

Controlar existencias no solo por cantidad total, sino también por lote/partida y fecha de vencimiento.

### Ejemplo

| Producto | Lote | Cantidad | Vencimiento |
|---|---|---:|---|
| Leche de almendras 1L | A | 8 | 2026-08-10 |
| Leche de almendras 1L | B | 12 | 2026-10-05 |

### Criterio FEFO

Para ventas, consumo interno, mermas y retiros por vencimiento, el sistema debe priorizar la salida del lote que vence primero.

```text
First Expired, First Out
Primero vence, primero sale
```

### Reglas

- El stock total del producto se calcula sumando lotes disponibles.
- Los lotes con cantidad cero pueden mantenerse por historial.
- No debe permitirse stock negativo salvo permiso administrativo especial.
- Todo egreso debe generar un movimiento de stock.
- Todo ajuste manual debe requerir motivo.

---

## 6. Movimientos de stock

Toda entrada o salida relevante debe registrarse como movimiento.

| Tipo | Descripción | Descuenta/Suma | Impacta caja |
|---|---|---:|---:|
| `INGRESO_COMPRA` | Entrada por compra/recepción | Suma | No |
| `EGRESO_VENTA` | Salida por venta | Resta | Sí |
| `CONSUMO_INTERNO` | Producto consumido por empleado/dueña | Resta | No |
| `MERMA` | Rotura, deterioro o pérdida | Resta | No |
| `VENCIMIENTO` | Producto retirado por vencimiento | Resta | No |
| `AJUSTE_POSITIVO` | Corrección que suma stock | Suma | No |
| `AJUSTE_NEGATIVO` | Corrección que resta stock | Resta | No |
| `DEVOLUCION` | Devolución o corrección | Depende | Depende |

### Campos comunes

- producto;
- lote;
- cantidad;
- tipo;
- motivo;
- usuario;
- fecha y hora;
- referencia asociada;
- observaciones.

---

## 7. Consumo interno de empleados

### Objetivo

Registrar productos que los empleados o la dueña consumen dentro del negocio, evitando que el stock desaparezca sin justificación.

### Flujo

```text
Seleccionar producto
        ↓
Indicar cantidad
        ↓
Seleccionar razón
        ↓
Confirmar consumo
        ↓
Descontar stock usando FEFO
        ↓
Registrar movimiento de stock
        ↓
Auditar acción
```

### Razones sugeridas

| Razón | Descripción |
|---|---|
| `CONSUMO_EMPLEADO` | Producto consumido por empleado durante su turno |
| `CONSUMO_DUENA` | Producto consumido por la dueña |
| `DEGUSTACION` | Producto abierto para degustación de clientes |
| `MUESTRA` | Producto usado como muestra o exhibición |
| `CAPACITACION` | Producto usado para prueba interna |
| `OTRO` | Requiere descripción manual |

### Reglas

- Descuenta stock.
- No genera ingreso de caja.
- Requiere usuario, producto, cantidad, fecha y razón.
- Puede requerir aprobación de la administradora.
- Debe distinguirse de venta, merma y vencimiento.
- Debe aparecer en reportes de movimientos de stock.

---

## 8. Mermas y vencimientos

### Objetivo

Permitir registrar pérdidas o retiros de productos con motivo claro.

### Casos

- Producto vencido.
- Producto próximo a vencer retirado.
- Envase roto.
- Producto deteriorado.
- Pérdida detectada en inventario.
- Producto usado para muestra.

### Reglas

- Descuenta stock.
- Requiere motivo.
- Debe registrar usuario.
- Debe afectar lote si corresponde.
- No genera movimiento de caja.
- Debe ser auditable.

---

# Proveedores y listas de precios

## Objetivo

Modelar la relación real de la dietética con varios proveedores, considerando que cada proveedor puede enviar listas de precios de forma distinta.

El sistema debe permitir cargar esas listas, normalizarlas, compararlas con información anterior, detectar cambios de costo y asistir a la dueña en la actualización de precios de venta y reposición.

---

## Métodos de carga incluidos

### 1. Importación desde Excel

Para proveedores que envían planillas estructuradas.

Columnas posibles:

| Columna | Descripción |
|---|---|
| Código proveedor | Código propio del proveedor, si existe |
| Producto | Nombre del producto en la lista del proveedor |
| Presentación | Tamaño, unidad o variante |
| Costo | Precio de compra informado |
| Stock proveedor | Disponible si el proveedor lo informa |
| Observaciones | Comentarios adicionales |

### 2. Texto copiado desde WhatsApp

Para proveedores que mandan listas como mensaje escrito.

Ejemplo:

```text
Avena integral 1kg $2450
Chía 250g $1800
Harina de almendras 500g $7200
```

El sistema puede ofrecer una pantalla donde se pega el texto y se revisan las líneas detectadas.

### 3. Carga manual

Para cambios puntuales o listas chicas.

Datos mínimos:

- proveedor;
- producto del proveedor;
- costo nuevo;
- fecha de lista;
- observación opcional.

---

## Métodos fuera de alcance

No se incluye:

- PDF;
- imagen/foto;
- OCR;
- audio de WhatsApp;
- lectura automática desde catálogos web.

> [!important]
> Esta decisión mantiene el proyecto acotado y evita depender de reconocimiento óptico de caracteres o parsing complejo de documentos no estructurados.

---

## Producto interno vs producto del proveedor

Un mismo producto interno puede aparecer con nombres distintos según el proveedor.

### Ejemplo

| Producto interno | Proveedor | Nombre en lista del proveedor |
|---|---|---|
| Avena integral 1kg | Proveedor A | Avena int. x1kg |
| Avena integral 1kg | Proveedor B | Avena integral bolsa kilo |
| Avena integral 1kg | Proveedor C | AVENA INTEGRAL 1000G |

Para resolver esto, el sistema necesita una entidad intermedia: `ProductoProveedor` o `MapeoProductoProveedor`.

---

## Flujo de importación de lista de precios

```text
Seleccionar proveedor
        ↓
Elegir método de carga: Excel, WhatsApp o manual
        ↓
Cargar datos
        ↓
Normalizar líneas/items
        ↓
Intentar reconocer productos internos
        ↓
Clasificar coincidencias
        ↓
Mostrar comparación de costos
        ↓
Revisar y aprobar cambios
        ↓
Actualizar costo proveedor e historial
        ↓
Sugerir precio de venta
        ↓
Generar etiquetas pendientes si cambia precio de venta
        ↓
Auditar importación
```

---

## Estados de reconocimiento de ítems

| Estado | Significado |
|---|---|
| `RECONOCIDO` | El sistema encontró una asociación clara con un producto interno |
| `POSIBLE_COINCIDENCIA` | El sistema sugiere uno o más productos internos posibles |
| `NO_RECONOCIDO` | No se encontró producto interno asociado |
| `NUEVO_PRODUCTO` | Podría crearse un nuevo producto a partir de la lista |
| `IGNORADO` | La línea no se aplicará |

---

## Revisión de diferencias

Antes de aplicar cambios, la dueña debe ver una comparación.

| Producto | Proveedor | Costo anterior | Costo nuevo | Diferencia | Acción |
|---|---|---:|---:|---:|---|
| Avena integral 1kg | Proveedor A | $2.100 | $2.450 | +16.6% | Aplicar |
| Chía 250g | Proveedor A | $1.500 | $1.800 | +20.0% | Aplicar |
| Almendras 500g | Proveedor B | $6.800 | $7.100 | +4.4% | Revisar |
| Mix proteico 200g | Proveedor C | - | $3.200 | - | Crear/ignorar |

---

## Costo proveedor vs precio de venta

El sistema debe separar claramente:

| Concepto | Significado |
|---|---|
| Costo proveedor | Precio al que se compra o se compraría al proveedor |
| Precio de venta | Precio cobrado al cliente |
| Margen | Diferencia estimada entre costo y precio de venta |
| Precio sugerido | Precio calculado por el sistema según regla de margen/redondeo |

### Ejemplo

```text
Producto: Avena integral 1kg
Costo anterior: $2.100
Costo nuevo: $2.450
Precio de venta actual: $3.200
Margen antes del cambio: 34.37%
Margen después del cambio: 23.44%
Precio sugerido para mantener margen: $3.750
```

---

## Actualización asistida de precios

No se recomienda una actualización automática ciega. El enfoque propuesto es **actualización asistida con aprobación**.

### Modos posibles

| Modo | Descripción |
|---|---|
| Solo actualizar costo | Cambia el costo proveedor, pero no el precio de venta |
| Sugerir precio venta | Calcula precio sugerido sin aplicarlo automáticamente |
| Aplicar cambios seleccionados | La dueña aprueba qué precios se actualizan |
| Aplicar lote de cambios | La dueña confirma un conjunto de cambios filtrados |

---

## Reglas de margen y redondeo

El sistema puede permitir reglas por categoría o producto.

### Ejemplo de reglas por categoría

| Categoría | Margen deseado | Redondeo |
|---|---:|---|
| Semillas | 35% | A $50 |
| Frutos secos | 30% | A $100 |
| Suplementos | 40% | A $100 |
| Refrigerados | 25% | A $50 |

### Reglas

- El margen puede configurarse por producto o categoría.
- Si no hay regla específica, se usa una regla general.
- El precio sugerido debe poder revisarse antes de aplicar.
- El redondeo debe ser visible para la dueña.
- El cambio de precio debe generar historial.
- Si cambia el precio de venta, deben marcarse etiquetas pendientes.

---

## Comparación entre proveedores

Cuando un producto tiene varios proveedores asociados, el sistema puede comparar los costos registrados.

| Producto | Proveedor | Último costo | Fecha lista | Estado |
|---|---|---:|---|---|
| Avena integral 1kg | Proveedor A | $2.450 | 2026-04-22 | Actualizado |
| Avena integral 1kg | Proveedor B | $2.390 | 2026-04-20 | Actualizado |
| Avena integral 1kg | Proveedor C | $2.600 | 2026-04-10 | Viejo |

El sistema puede mostrar:

- proveedor habitual;
- proveedor con menor costo actualizado;
- diferencia porcentual;
- fecha de última actualización;
- advertencia si la lista está vieja.

> [!note]
> El sistema puede sugerir, pero la decisión final de compra queda en manos de la dueña.

---

## Relación con reposición sugerida

La reposición sugerida puede usar información de stock y proveedor.

```text
Stock actual < stock mínimo
        ↓
Calcular cantidad sugerida
        ↓
Buscar proveedor habitual o mejor costo reciente
        ↓
Agrupar productos por proveedor
        ↓
Generar pedido borrador
```

### Fórmula simple inicial

```text
cantidad_sugerida = stock_ideal - stock_actual
```

---

# Pedidos a proveedores

## Objetivo

Permitir crear pedidos de reposición a partir de carga manual o sugerencias del sistema.

## Estados

| Estado | Descripción |
|---|---|
| `BORRADOR` | Pedido en armado |
| `ENVIADO` | Pedido enviado al proveedor |
| `RECIBIDO_PARCIAL` | Llegó solo parte de lo pedido |
| `RECIBIDO` | Pedido recibido completamente |
| `CANCELADO` | Pedido cancelado |

## Datos del pedido

- proveedor;
- fecha;
- estado;
- productos solicitados;
- cantidad solicitada;
- cantidad recibida;
- costo esperado;
- observaciones.

---

# Recepción de mercadería

## Objetivo

Registrar lo que efectivamente llega al local, actualizar stock y cargar vencimientos.

## Flujo

```text
Seleccionar pedido o carga manual
        ↓
Ingresar cantidades recibidas
        ↓
Cargar vencimientos/lotes
        ↓
Confirmar recepción
        ↓
Actualizar stock
        ↓
Registrar movimientos de ingreso
        ↓
Actualizar costo si corresponde
        ↓
Auditar acción
```

## Reglas

- Puede recibirse un pedido total o parcialmente.
- La recepción actualiza stock.
- Si el producto tiene vencimiento, debe cargarse.
- La recepción genera movimiento de stock `INGRESO_COMPRA`.
- La cantidad recibida no necesariamente coincide con la cantidad solicitada.
- El costo recibido puede actualizar historial de costo proveedor.

---

# Caja interna

## Objetivo

Controlar ingresos y egresos básicos sin implementar contabilidad completa.

## Tipos de movimiento

| Tipo | Descripción |
|---|---|
| `INGRESO_VENTA` | Generado automáticamente por venta confirmada |
| `INGRESO_MANUAL` | Ingreso cargado manualmente |
| `EGRESO_MANUAL` | Salida de dinero |
| `RETIRO` | Retiro de caja |
| `GASTO_OPERATIVO` | Gasto del local |
| `AJUSTE` | Corrección manual |

## Reglas

- Toda venta confirmada genera un ingreso de caja.
- El consumo interno no genera caja.
- Las mermas no generan caja.
- Todo egreso manual requiere concepto.
- El cierre compara saldo esperado contra saldo contado.
- Un cierre confirmado queda bloqueado para usuarios comunes.

---

# Cierre de turno y cierre diario

## Cierre de turno

Orientado al empleado.

Datos posibles:

- usuario;
- hora de inicio;
- hora de cierre;
- cantidad de ventas registradas;
- estado de caja del turno;
- observaciones;
- tareas pendientes.

## Cierre diario

Orientado a la administradora.

Datos posibles:

- fecha;
- saldo inicial;
- ingresos por ventas;
- otros ingresos;
- egresos;
- saldo esperado;
- saldo contado;
- diferencia;
- observaciones;
- usuario responsable.

---

# Etiquetas de precios

## Objetivo

Generar etiquetas imprimibles cuando se crean productos, cambian precios o existen ofertas.

## Casos

- Precio de venta actualizado.
- Oferta temporal creada.
- Etiqueta desactualizada detectada.
- Producto nuevo.
- Cambio de presentación.

## Datos posibles de etiqueta

- nombre producto;
- presentación;
- precio venta;
- precio oferta si aplica;
- código de barras si corresponde;
- fecha de actualización;
- categoría opcional.

## Regla

Cuando un precio de venta cambia, el producto debe quedar marcado como `etiquetaPendiente = true` hasta que se imprima o se marque como resuelto.

---

# Reportes operativos

## Reportes para administradora

- Stock actual.
- Stock bajo.
- Productos próximos a vencer.
- Productos vencidos.
- Ventas por día.
- Ventas por turno.
- Productos más vendidos.
- Movimientos de caja.
- Cierres diarios.
- Consumos internos.
- Mermas.
- Cambios de precio.
- Importaciones de listas.
- Comparación de costos por proveedor.
- Etiquetas pendientes.

## Reportes para empleado

- Ventas del propio turno.
- Productos a revisar.
- Productos próximos a vencer.
- Tareas pendientes.
- Estado de turno.

---

# Auditoría

## Objetivo

Registrar acciones relevantes para trazabilidad.

## Acciones auditables

- Login/logout si se requiere.
- Creación/modificación/desactivación de producto.
- Cambio de precio.
- Creación/modificación/desactivación de oferta.
- Confirmación de venta.
- Anulación de venta.
- Modificación manual de precio en venta.
- Consumo interno.
- Merma.
- Ajuste de stock.
- Importación de lista de precios.
- Aprobación de cambios de precio.
- Recepción de mercadería.
- Cierre de turno.
- Cierre diario.
- Cambio de permisos.

## Campos sugeridos

- usuario;
- acción;
- entidad;
- entidadId;
- fechaHora;
- datosAntes;
- datosDespués;
- detalle;
- ip/dispositivo opcional.

---

# Vistas propuestas

## Login

Referencia visual: [Pantalla de login](attachments/lembas-login.png)

Funcionalidad:

- ingreso con usuario/email;
- contraseña;
- recordar sesión;
- recuperación de contraseña como mejora posterior;
- estética coherente con una dietética.

## Home de administradora

Referencia visual: [Home de administración](attachments/lembas-home-admin.png)

Debe responder:

- ¿Cuánto se vendió hoy?
- ¿Cómo está la caja?
- ¿Qué productos faltan?
- ¿Qué productos vencen pronto?
- ¿Qué debo reponer?
- ¿Hubo cambios de precio pendientes?
- ¿Qué pedidos/listas requieren revisión?
- ¿Qué tareas críticas hay?

Componentes sugeridos:

- KPIs generales;
- tareas de gestión;
- productos próximos a vencer;
- reposición sugerida;
- últimas ventas;
- alertas de precios/listas;
- accesos a proveedores, pedidos, stock, caja y reportes.

## Home de empleado refinada

Referencia visual: [Home de empleado refinada](attachments/lembas-home-empleado-refinada.png)

Debe responder:

- ¿Qué tengo que hacer ahora?
- ¿Dónde registro una venta?
- ¿Qué productos debo revisar?
- ¿Qué productos están próximos a vencer?
- ¿Qué ventas hice en mi turno?
- ¿La caja del turno está abierta o pendiente de cierre?

No debe mostrar:

- proveedores;
- costos;
- márgenes;
- reportes globales;
- configuración;
- auditoría completa;
- métricas financieras estratégicas;
- paneles redundantes.

---

# Modelo de datos conceptual

## Entidades principales

```text
Usuario
Rol
Permiso

Producto
Categoria
Marca
Presentacion
CodigoBarra

Proveedor
ProductoProveedor
ListaPrecioProveedor
ItemListaPrecioProveedor
HistorialCostoProveedor
ReglaPrecio
HistorialPrecioVenta

LoteStock
MovimientoStock
RazonMovimientoStock

Venta
DetalleVenta

OfertaTemporal

ConsumoInterno
DetalleConsumoInterno

MovimientoCaja
TurnoCaja
CierreCaja

PedidoProveedor
DetallePedidoProveedor
RecepcionMercaderia
DetalleRecepcionMercaderia

InventarioFisico
DetalleInventarioFisico

EtiquetaPrecio
AlertaOperativa
Auditoria
```

---

# Entidades destacadas

## Producto

Representa un producto interno de la dietética.

Campos posibles:

- `id`;
- `nombre`;
- `descripcion`;
- `categoriaId`;
- `marcaId`;
- `presentacion`;
- `codigoBarras`;
- `precioVentaBase`;
- `costoEstimado`;
- `stockMinimo`;
- `stockIdeal`;
- `activo`;
- `requiereVencimiento`;
- `etiquetaPendiente`;
- `proveedorHabitualId`;
- `createdAt`;
- `updatedAt`.

## Proveedor

Representa un proveedor de la dietética.

Campos posibles:

- `id`;
- `nombreComercial`;
- `contacto`;
- `telefono`;
- `whatsapp`;
- `email`;
- `direccion`;
- `metodoListaHabitual`;
- `activo`;
- `observaciones`.

## ProductoProveedor

Mapea un producto interno con el producto según el proveedor.

Campos posibles:

- `id`;
- `productoId`;
- `proveedorId`;
- `codigoProveedor`;
- `nombreProveedor`;
- `presentacionProveedor`;
- `ultimoCosto`;
- `fechaUltimaActualizacion`;
- `esHabitual`;
- `activo`.

## ListaPrecioProveedor

Representa una lista cargada desde Excel, texto de WhatsApp o carga manual.

Campos posibles:

- `id`;
- `proveedorId`;
- `metodoCarga`;
- `nombreArchivoOriginal`;
- `textoOriginal`;
- `fechaLista`;
- `fechaCarga`;
- `usuarioCargaId`;
- `estado`;
- `observaciones`.

Estados posibles:

- `CARGADA`;
- `PROCESADA`;
- `EN_REVISION`;
- `APLICADA`;
- `DESCARTADA`;
- `CON_ERRORES`.

## ItemListaPrecioProveedor

Representa una línea de la lista.

Campos posibles:

- `id`;
- `listaPrecioProveedorId`;
- `productoProveedorId`;
- `productoInternoSugeridoId`;
- `nombreDetectado`;
- `presentacionDetectada`;
- `codigoDetectado`;
- `costoNuevo`;
- `costoAnterior`;
- `diferenciaPorcentual`;
- `stockProveedor`;
- `estadoReconocimiento`;
- `accionSeleccionada`;
- `observaciones`.

## HistorialCostoProveedor

Guarda la evolución del costo por proveedor.

Campos posibles:

- `id`;
- `productoProveedorId`;
- `costo`;
- `fechaVigencia`;
- `listaPrecioProveedorId`;
- `usuarioId`;
- `createdAt`.

## ReglaPrecio

Define reglas para sugerir precio de venta.

Campos posibles:

- `id`;
- `categoriaId` opcional;
- `productoId` opcional;
- `margenDeseado`;
- `tipoRedondeo`;
- `activa`.

## HistorialPrecioVenta

Guarda cambios del precio de venta.

Campos posibles:

- `id`;
- `productoId`;
- `precioAnterior`;
- `precioNuevo`;
- `motivo`;
- `origen`;
- `usuarioId`;
- `createdAt`.

## LoteStock

Representa una cantidad de un producto con vencimiento.

Campos posibles:

- `id`;
- `productoId`;
- `cantidadDisponible`;
- `fechaVencimiento`;
- `fechaIngreso`;
- `proveedorId`;
- `recepcionMercaderiaId`;
- `observaciones`.

## MovimientoStock

Representa una entrada o salida de stock.

Campos posibles:

- `id`;
- `productoId`;
- `loteStockId`;
- `tipo`;
- `cantidad`;
- `motivo`;
- `usuarioId`;
- `fechaHora`;
- `referenciaTipo`;
- `referenciaId`.

## Venta

Representa una venta mostrador simplificada.

Campos posibles:

- `id`;
- `fechaHora`;
- `usuarioId`;
- `estado`;
- `subtotal`;
- `descuentoTotal`;
- `total`;
- `movimientoCajaId`;
- `observaciones`.

## DetalleVenta

Representa una línea de venta.

Campos posibles:

- `id`;
- `ventaId`;
- `productoId`;
- `cantidad`;
- `precioBaseHistorico`;
- `precioAplicado`;
- `descuentoAplicado`;
- `ofertaTemporalId`;
- `motivoCambioPrecio`;
- `subtotal`.

## OfertaTemporal

Representa una promoción temporal.

Campos posibles:

- `id`;
- `productoId`;
- `nombre`;
- `tipo`;
- `porcentajeDescuento`;
- `precioPromocional`;
- `fechaInicio`;
- `fechaFin`;
- `activa`;
- `prioridad`;
- `usuarioCreadorId`;
- `observaciones`.

## ConsumoInterno

Representa un consumo de productos dentro del negocio.

Campos posibles:

- `id`;
- `usuarioId`;
- `fechaHora`;
- `razon`;
- `estado`;
- `requiereAprobacion`;
- `aprobadoPorUsuarioId`;
- `observaciones`.

## MovimientoCaja

Representa un ingreso o egreso.

Campos posibles:

- `id`;
- `tipo`;
- `concepto`;
- `monto`;
- `fechaHora`;
- `usuarioId`;
- `ventaId`;
- `turnoCajaId`;
- `observaciones`.

## Auditoria

Representa una acción crítica.

Campos posibles:

- `id`;
- `usuarioId`;
- `accion`;
- `entidad`;
- `entidadId`;
- `fechaHora`;
- `datosAntes`;
- `datosDespues`;
- `detalle`.

---

# Estados principales

## Venta

```text
BORRADOR → CONFIRMADA → ANULADA
```

## Lista de precios

```text
CARGADA → PROCESADA → EN_REVISION → APLICADA
                         ↓
                    DESCARTADA
```

## Pedido proveedor

```text
BORRADOR → ENVIADO → RECIBIDO_PARCIAL → RECIBIDO
    ↓           ↓
 CANCELADO   CANCELADO
```

## Oferta temporal

```text
PROGRAMADA → ACTIVA → VENCIDA
      ↓         ↓
   INACTIVA  INACTIVA
```

## Turno caja

```text
ABIERTO → PENDIENTE_CIERRE → CERRADO
```

## Consumo interno

```text
REGISTRADO → APROBADO
     ↓
 RECHAZADO
```

---

# Reglas de negocio consolidadas

## Productos

- Un producto puede tener código de barras o no.
- El código de barras no debe repetirse entre productos activos.
- Un producto inactivo no debe venderse.
- Un producto puede estar asociado a varios proveedores.
- Un producto puede tener proveedor habitual.
- El precio de venta debe ser mayor o igual a cero.
- Todo cambio de precio debe guardar historial.

## Stock

- El stock se calcula a partir de lotes y movimientos.
- No se debe permitir stock negativo salvo excepción administrativa.
- Las salidas deben usar FEFO cuando existan vencimientos.
- Todo ajuste manual requiere motivo.
- Todo movimiento registra usuario, fecha, tipo y referencia.

## Ventas

- Una venta confirmada descuenta stock.
- Una venta confirmada genera ingreso de caja.
- Una venta no debe eliminarse físicamente.
- Una anulación debe generar compensaciones o reversión trazable.
- El detalle guarda precio aplicado histórico.
- La confirmación debe ser transaccional.

## Ofertas

- Deben tener fecha de inicio y fin.
- No se aplican si están vencidas o inactivas.
- Si existen varias ofertas, debe aplicarse una regla de prioridad.
- La venta guarda la oferta aplicada.

## Precios proveedor

- Una lista importada no debe modificar precios sin revisión.
- Todo cambio aplicado debe guardar historial.
- El costo proveedor no es lo mismo que el precio de venta.
- Los ítems no reconocidos deben resolverse manualmente o ignorarse.
- No se procesa PDF/imagen/OCR.

## Consumo interno

- Descuenta stock.
- No genera caja.
- Requiere razón.
- Puede requerir aprobación.
- Debe diferenciarse de venta y merma.

## Caja

- Toda venta confirmada genera ingreso.
- Los egresos manuales requieren concepto.
- El cierre compara saldo esperado y contado.
- Los cierres confirmados no deberían modificarse sin permiso.

## Auditoría

- Las acciones críticas se auditan.
- La auditoría no debe ser editable por usuarios comunes.
- Deben auditarse ventas, anulaciones, importaciones, cambios de precio, ofertas, consumos, mermas, cierres y permisos.

---

# Casos de uso principales

## Productos y stock

- Registrar producto.
- Editar producto.
- Desactivar producto.
- Asignar código de barras.
- Consultar producto por código.
- Registrar ingreso de stock.
- Registrar ajuste de stock.
- Registrar consumo interno.
- Registrar merma.
- Consultar lotes.
- Consultar vencimientos.
- Consultar stock bajo.

## Ventas

- Escanear producto.
- Buscar producto manualmente.
- Agregar producto a venta.
- Modificar cantidad.
- Modificar precio con permiso.
- Aplicar oferta temporal.
- Quitar producto.
- Confirmar venta.
- Descontar stock.
- Registrar caja.
- Anular venta.
- Consultar ventas del turno.

## Proveedores y precios

- Registrar proveedor.
- Asociar proveedor a producto.
- Cargar lista Excel.
- Pegar lista de WhatsApp.
- Cargar precio manual.
- Revisar coincidencias.
- Aplicar cambios de costo.
- Sugerir precio de venta.
- Aplicar cambios seleccionados.
- Generar etiquetas pendientes.
- Comparar costos por proveedor.

## Reposición y recepción

- Consultar productos bajo mínimo.
- Generar reposición sugerida.
- Agrupar sugerencias por proveedor.
- Crear pedido borrador.
- Marcar pedido enviado.
- Registrar recepción parcial o total.
- Cargar vencimientos.
- Actualizar stock.

## Caja

- Registrar ingreso manual.
- Registrar egreso manual.
- Consultar movimientos.
- Cerrar turno.
- Cerrar día.
- Registrar diferencia de caja.

## Ofertas

- Crear oferta.
- Editar oferta.
- Activar/desactivar oferta.
- Aplicar oferta en venta.
- Consultar ofertas vigentes.
- Consultar historial.

## Reportes

- Stock actual.
- Bajo stock.
- Próximos vencimientos.
- Ventas por día.
- Ventas por turno.
- Productos más vendidos.
- Movimientos de caja.
- Consumos internos.
- Mermas.
- Cambios de precio.
- Listas importadas.
- Etiquetas pendientes.

---

# Arquitectura propuesta

## Estilo arquitectónico

Se propone un **monolito modularizado**.

Justificación:

- menor complejidad operativa;
- despliegue más simple;
- facilita desarrollo académico;
- permite separación clara de módulos;
- mantiene abierta la posibilidad de extraer servicios futuros.

## Tecnologías principales

| Capa | Tecnología |
|---|---|
| Frontend | Angular |
| Backend | Spring Boot |
| Base de datos | PostgreSQL |
| Persistencia | Spring Data JPA / Hibernate |
| Seguridad | Spring Security + JWT |
| Documentación API | OpenAPI / Swagger |
| Importación Excel | Apache POI |
| Validaciones | Bean Validation |
| Migraciones | Flyway o Liquibase |
| Despliegue | Nube |
| Arquitectura | Monolito modularizado |

---

# Módulos backend sugeridos

```text
users
security
products
stock
sales
cash
suppliers
price-lists
pricing
offers
internal-consumption
purchases
labels
reports
audit
imports
```

## Organización posible por paquete

```text
com.lembas
  ├── users
  ├── security
  ├── products
  ├── stock
  ├── sales
  ├── cash
  ├── suppliers
  ├── pricelists
  ├── pricing
  ├── offers
  ├── consumption
  ├── purchases
  ├── labels
  ├── reports
  ├── audit
  └── shared
```

---

# Endpoints REST orientativos

## Productos

```text
GET    /api/v1/products
GET    /api/v1/products/{id}
POST   /api/v1/products
PUT    /api/v1/products/{id}
PATCH  /api/v1/products/{id}/deactivate
GET    /api/v1/products/barcode/{barcode}
```

## Stock

```text
GET    /api/v1/stock
GET    /api/v1/stock/products/{productId}/lots
POST   /api/v1/stock/adjustments
POST   /api/v1/stock/mermas
GET    /api/v1/stock/low
GET    /api/v1/stock/expiring
```

## Ventas

```text
POST   /api/v1/sales
POST   /api/v1/sales/{id}/items
PATCH  /api/v1/sales/{id}/items/{itemId}
DELETE /api/v1/sales/{id}/items/{itemId}
POST   /api/v1/sales/{id}/confirm
POST   /api/v1/sales/{id}/cancel
GET    /api/v1/sales/today
GET    /api/v1/sales/shift
```

## Proveedores

```text
GET    /api/v1/suppliers
POST   /api/v1/suppliers
PUT    /api/v1/suppliers/{id}
GET    /api/v1/suppliers/{id}/products
POST   /api/v1/suppliers/{id}/products
```

## Listas de precios

```text
POST   /api/v1/suppliers/{supplierId}/price-lists/excel
POST   /api/v1/suppliers/{supplierId}/price-lists/text
POST   /api/v1/suppliers/{supplierId}/price-lists/manual
GET    /api/v1/price-lists/{id}
GET    /api/v1/price-lists/{id}/items
PATCH  /api/v1/price-lists/{id}/items/{itemId}/resolve
POST   /api/v1/price-lists/{id}/apply
POST   /api/v1/price-lists/{id}/discard
```

## Precios

```text
GET    /api/v1/pricing/suggestions
POST   /api/v1/pricing/apply
GET    /api/v1/products/{id}/price-history
```

## Ofertas

```text
GET    /api/v1/offers
POST   /api/v1/offers
PUT    /api/v1/offers/{id}
PATCH  /api/v1/offers/{id}/activate
PATCH  /api/v1/offers/{id}/deactivate
GET    /api/v1/products/{id}/active-offer
```

## Consumo interno

```text
POST   /api/v1/internal-consumptions
GET    /api/v1/internal-consumptions
POST   /api/v1/internal-consumptions/{id}/approve
POST   /api/v1/internal-consumptions/{id}/reject
```

## Caja

```text
GET    /api/v1/cash/movements
POST   /api/v1/cash/movements
POST   /api/v1/cash/shifts/open
POST   /api/v1/cash/shifts/{id}/close
POST   /api/v1/cash/daily-closures
```

---

# Consideraciones transaccionales

## Confirmar venta

Debe ejecutarse en una transacción:

1. validar venta en borrador;
2. validar stock disponible;
3. resolver oferta/precio aplicado;
4. descontar lotes por FEFO;
5. crear movimientos de stock;
6. crear movimiento de caja;
7. cambiar venta a confirmada;
8. auditar.

Si algún paso falla, se revierte todo.

## Aplicar lista de precios

Debe ejecutarse en una transacción:

1. validar lista en revisión;
2. tomar ítems seleccionados;
3. actualizar costo proveedor;
4. crear historial de costo;
5. aplicar precios de venta aprobados;
6. crear historial de precio;
7. marcar etiquetas pendientes;
8. cambiar estado de lista;
9. auditar.

## Registrar consumo interno

Debe ejecutarse en una transacción:

1. validar producto y cantidad;
2. validar permiso/aprobación;
3. descontar stock por FEFO;
4. crear movimiento de stock;
5. guardar consumo;
6. auditar.

---

# MVP propuesto

Para una primera versión sólida y defendible:

1. Login y roles básicos.
2. Productos con código de barras.
3. Categorías y marcas simples.
4. Stock por lotes y vencimiento.
5. Venta mostrador con scanner.
6. Modificación de cantidad en venta.
7. Modificación de precio en venta con permiso/motivo.
8. Ofertas temporales simples.
9. Descuento automático de stock.
10. Caja con movimiento automático por venta.
11. Cierre de turno.
12. Consumo interno con razón.
13. Mermas simples.
14. Proveedores.
15. ProductoProveedor.
16. Importación Excel de lista de precios.
17. Carga de texto de WhatsApp.
18. Revisión y aplicación asistida de costos/precios.
19. Etiquetas pendientes.
20. Reportes básicos.
21. Auditoría de acciones críticas.

---

# Futuras mejoras

- Pedidos a proveedores completos si no entran en MVP.
- Recepción avanzada con control de parciales.
- Inventario físico completo.
- Integración con Mercado Pago.
- Facturación fiscal.
- AFIP.
- App móvil nativa.
- Lectura de código de barras desde cámara.
- Dashboard avanzado.
- Comparación histórica de proveedores.
- Notificaciones por WhatsApp/email.
- Productos vendidos por peso.
- Combos/promociones más avanzadas.

---

# Riesgos y controles

| Riesgo | Control |
|---|---|
| Alcance demasiado grande | Mantener POS fiscal, pagos, AFIP, OCR y e-commerce fuera de alcance |
| Stock inconsistente | Usar transacciones y movimientos de stock auditables |
| Precios mal importados | Revisión humana antes de aplicar cambios |
| Productos no reconocidos en listas | Estados de reconocimiento y resolución manual |
| Empleados viendo información sensible | RBAC y vistas diferenciadas |
| Cambios de precio sin control | Permisos, motivo e historial |
| Consumo interno abusivo | Razones, auditoría y aprobación opcional |
| Caja y ventas descuadradas | Relacionar venta confirmada con movimiento de caja |
| Vencimientos mal descontados | Criterio FEFO |
| Etiquetas desactualizadas | Marcar etiquetas pendientes tras cambios de precio |

---

# Decisiones tomadas

| Tema | Decisión |
|---|---|
| Sucursales | Una sola |
| Usuarios | Administradora/dueña y empleados |
| Ventas | Venta mostrador simplificada |
| POS completo | Fuera de alcance |
| Facturación fiscal | Fuera de alcance |
| Pasarela de pagos | Fuera de alcance |
| Scanner | Lector de código de barras tipo teclado |
| Caja | Ingresos, egresos, cierre de turno y cierre diario |
| Stock | Por producto, lote y vencimiento |
| Descuento de stock | Venta, consumo interno, merma, vencimiento y ajuste |
| Criterio de salida | FEFO |
| Consumo interno | Permitido con razón y auditoría |
| Ofertas temporales | Permitidas por producto y rango de fechas |
| Modificación de precio en venta | Permitida con motivo y permisos |
| Modificación de cantidad en venta | Permitida antes de confirmar |
| Proveedores | Varios proveedores por producto |
| Listas de precios | Excel, texto WhatsApp y carga manual |
| PDF/Imagen/OCR | Fuera de alcance |
| Actualización de precios | Asistida con aprobación |
| Excel | Importación/exportación permitidas |
| Frontend | Angular |
| Backend | Spring Boot |
| Base de datos | PostgreSQL |
| Arquitectura | Monolito modularizado |
| Despliegue | Nube |
| UX | Mobile-first y vistas por rol |

---

# Descripción final del sistema

Lembas será una plataforma web de gestión interna para una dietética de una sola sucursal.

El sistema permitirá administrar productos, stock por lote y vencimiento, ventas mostrador con código de barras, caja del turno, consumo interno, mermas, ofertas temporales, proveedores, listas de precios, actualización asistida de costos/precios, etiquetas y reportes operativos.

A diferencia de un CRUD tradicional, Lembas acompañará procesos reales del negocio: escanear productos, vender, descontar stock, registrar ingresos en caja, controlar vencimientos, justificar consumos internos, comparar costos entre proveedores, actualizar precios con revisión, generar etiquetas y mantener trazabilidad de acciones críticas.

La solución se desarrollará como monolito modularizado con Spring Boot, Angular y PostgreSQL, priorizando claridad arquitectónica, reglas de negocio explícitas, seguridad por roles, trazabilidad y posibilidad de evolución futura.
