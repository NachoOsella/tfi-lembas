---
title: Reglas de negocio
aliases:
  - RN del sistema
  - Reglas operativas
  - Reglas de dominio Lembas
tags:
  - tpf
  - negocio
  - reglas
  - dominio
  - stock
  - caja
  - venta-simplificada
cssclasses:
  - wide-page
---

# Reglas de negocio

> [!abstract]
> Las reglas de negocio establecen restricciones y comportamientos obligatorios del dominio de Lembas. Están alineadas con [[00 - TPF Dietética Lembas]] y sirven como base para validaciones, pruebas, servicios de dominio y defensa del TPF. Esta versión incorpora reglas específicas para proveedores, listas de precios, actualización asistida, reposición, pedidos y recepción de mercadería.

## Usuarios, roles y permisos

| ID | Regla |
|---|---|
| RN-01 | Todo usuario debe autenticarse para operar en el sistema. |
| RN-02 | Un usuario inactivo no puede iniciar sesión ni registrar operaciones. |
| RN-03 | La administradora/dueña puede acceder a módulos de configuración, usuarios, reportes, auditoría, caja completa y gestión general. |
| RN-04 | El empleado solo puede acceder a funcionalidades operativas habilitadas por su rol. |
| RN-05 | Las acciones sensibles deben registrar usuario, fecha, hora, entidad afectada y detalle relevante. |
| RN-06 | La información sensible del negocio, como reportes financieros, márgenes, costos o auditoría completa, no debe mostrarse al empleado salvo permiso explícito. |

## Productos

| ID | Regla |
|---|---|
| RN-07 | Un producto no debe eliminarse físicamente si tiene ventas, movimientos de stock o historial asociado. |
| RN-08 | La baja de producto debe ser lógica y conservar su trazabilidad histórica. |
| RN-09 | Un producto inactivo no debe poder agregarse a nuevas ventas ni nuevos ingresos operativos, salvo reactivación o corrección administrativa. |
| RN-10 | El código de barras es opcional, pero si existe no debe repetirse entre productos activos. |
| RN-11 | El precio de venta base no puede ser negativo. |
| RN-12 | Todo cambio relevante de precio debe quedar registrado con usuario, fecha y valor anterior/nuevo. |
| RN-13 | El costo estimado puede ser visible solo para administradora o usuarios autorizados. |
| RN-14 | El stock mínimo e ideal deben ser valores mayores o iguales a cero. |
| RN-14.1 | Un producto puede estar asociado a varios proveedores, pero solo uno debería marcarse como habitual por defecto. |
| RN-14.2 | El producto interno debe distinguirse del nombre o código utilizado por cada proveedor. |
| RN-14.3 | Si cambia el precio de venta, el producto debe quedar marcado con etiqueta pendiente hasta imprimirla o resolverla.

## Stock y lotes

| ID | Regla |
|---|---|
| RN-15 | El stock disponible debe calcularse a partir de lotes y movimientos registrados. |
| RN-16 | Todo ingreso de stock debe identificar producto, cantidad, usuario, fecha y motivo u origen. |
| RN-17 | Si el producto maneja vencimiento, el ingreso debe registrar fecha de vencimiento o lote equivalente. |
| RN-18 | La cantidad de un lote no puede quedar negativa por una operación normal. |
| RN-19 | No debe permitirse vender, consumir o dar de baja más unidades que las disponibles, salvo autorización excepcional auditada. |
| RN-20 | Las salidas de productos con vencimiento deben aplicar FEFO: primero vence, primero sale. |
| RN-21 | Todo ajuste manual de stock debe requerir motivo. |
| RN-22 | Merma, vencimiento, consumo interno y venta son causas diferentes y no deben registrarse como un ajuste genérico si se conoce el motivo real. |
| RN-23 | Los productos próximos a vencer deben detectarse mediante un umbral configurable. |
| RN-24 | Los productos con stock total menor o igual al stock mínimo deben considerarse bajo stock. |
| RN-25 | El inventario físico debe conservar la diferencia entre stock teórico y conteo real antes de aplicar ajustes. |

## Movimientos de stock

| ID | Regla |
|---|---|
| RN-26 | Cada variación de stock debe generar un movimiento de stock. |
| RN-27 | Un movimiento de stock debe indicar tipo, cantidad, producto, lote afectado cuando corresponda, usuario, fecha y referencia. |
| RN-28 | Los movimientos originados por venta deben referenciar la venta confirmada. |
| RN-29 | Los movimientos originados por consumo interno deben referenciar el consumo registrado. |
| RN-30 | Los movimientos originados por merma o vencimiento deben registrar motivo descriptivo. |
| RN-31 | Los movimientos de stock no deben modificarse libremente; las correcciones deben realizarse mediante movimientos compensatorios. |

## Venta mostrador simplificada

| ID | Regla |
|---|---|
| RN-32 | Una venta puede iniciarse en estado borrador y solo impacta stock y caja al confirmarse. |
| RN-33 | Una venta confirmada debe generar egreso de stock. |
| RN-34 | Una venta confirmada debe generar ingreso de caja. |
| RN-35 | La confirmación de venta debe ser transaccional: si falla el stock, no debe registrarse caja; si falla caja, no debe confirmarse la venta. |
| RN-36 | La venta no debe eliminarse físicamente; para revertirla debe anularse o registrarse una operación compensatoria. |
| RN-37 | Una venta anulada debe conservar motivo, usuario responsable y fecha. |
| RN-38 | El lector de código de barras debe tratarse como entrada de teclado; el sistema debe buscar el producto al recibir el código. |
| RN-39 | Los productos sin código de barras deben poder buscarse manualmente. |
| RN-40 | La cantidad de una línea de venta debe ser mayor que cero. |
| RN-41 | El stock se descuenta recién al confirmar la venta, no al agregar productos al borrador. |

## Precios aplicados en venta

| ID | Regla |
|---|---|
| RN-42 | Cada detalle de venta debe guardar el precio base vigente al momento de la venta. |
| RN-43 | Cada detalle de venta debe guardar el precio aplicado final. |
| RN-44 | Si el precio aplicado difiere del precio base, debe registrarse motivo. |
| RN-45 | La modificación manual de precio debe depender de permisos o de límites configurados. |
| RN-46 | El administrador puede modificar precio en venta con motivo obligatorio. |
| RN-47 | El empleado solo puede modificar precio si tiene permiso específico o si la regla configurada lo permite. |
| RN-48 | La venta histórica no debe cambiar si luego se modifica el precio del producto. |
| RN-49 | Toda modificación manual de precio debe quedar auditada. |

## Ofertas temporales

| ID | Regla |
|---|---|
| RN-50 | Una oferta debe estar asociada a un producto. |
| RN-51 | Una oferta debe tener fecha de inicio y fecha de fin. |
| RN-52 | La fecha de fin no puede ser anterior a la fecha de inicio. |
| RN-53 | Una oferta inactiva o vencida no debe aplicarse automáticamente. |
| RN-54 | Si hay más de una oferta activa para un producto, debe existir una regla de prioridad. |
| RN-55 | La venta debe guardar el precio final aplicado y la referencia a la oferta si corresponde. |
| RN-56 | La modificación o desactivación de una oferta no debe alterar ventas históricas. |
| RN-57 | La creación, edición y desactivación de ofertas debe quedar auditada. |

## Consumo interno

| ID | Regla |
|---|---|
| RN-58 | El consumo interno descuenta stock. |
| RN-59 | El consumo interno no genera ingreso de caja. |
| RN-60 | Todo consumo interno debe registrar usuario, producto, cantidad, razón y fecha. |
| RN-61 | Si el producto tiene vencimientos, el consumo interno debe descontar stock por FEFO. |
| RN-62 | La razón `OTRO` debe requerir una descripción adicional. |
| RN-63 | El consumo interno puede requerir aprobación de administradora según configuración. |
| RN-64 | Un consumo interno rechazado no debe descontar stock. |
| RN-65 | El consumo interno debe aparecer en reportes de stock y no mezclarse con ventas o mermas. |

## Merma y vencimiento

| ID | Regla |
|---|---|
| RN-66 | Una merma debe descontar stock y registrar motivo. |
| RN-67 | Un retiro por vencimiento debe descontar stock y registrar lote o fecha de vencimiento afectada. |
| RN-68 | Las mermas y vencimientos no generan ingresos de caja. |
| RN-69 | Las mermas y vencimientos deben ser reportables por fecha, producto y usuario. |

## Caja, turnos y cierres

| ID | Regla |
|---|---|
| RN-70 | La caja o turno debe estar abierto para registrar movimientos operativos del día, según configuración. |
| RN-71 | Todo ingreso automático por venta debe referenciar la venta confirmada. |
| RN-72 | Todo ingreso o egreso manual debe tener concepto y responsable. |
| RN-73 | Los egresos manuales deben requerir monto positivo y tipo de egreso. |
| RN-74 | El cierre debe comparar saldo esperado contra saldo contado. |
| RN-75 | Toda diferencia de caja debe quedar registrada con observación si corresponde. |
| RN-76 | Un cierre confirmado no debe modificarse salvo por usuario administrador y con auditoría. |
| RN-77 | El empleado puede cerrar su turno o solicitar cierre según configuración. |
| RN-78 | El consumo interno no debe generar movimiento de caja. |

## Proveedores y listas de precios

| ID | Regla |
|---|---|
| RN-79 | Un proveedor puede estar activo o inactivo sin perder su historial. |
| RN-80 | La lista de precios debe asociarse siempre a un proveedor y a una fecha de lista o carga. |
| RN-81 | Las listas pueden cargarse por Excel, texto de WhatsApp o carga manual. |
| RN-82 | PDF, imágenes, fotos, OCR, audio y catálogos web quedan fuera del alcance inicial. |
| RN-83 | Una lista cargada no debe modificar costos ni precios sin revisión y aprobación. |
| RN-84 | Cada ítem de lista debe tener estado de reconocimiento. |
| RN-85 | Los ítems no reconocidos deben resolverse manualmente, crearse como nuevo producto o ignorarse. |
| RN-86 | El costo proveedor y el precio de venta son conceptos distintos y no deben mezclarse. |
| RN-87 | Todo cambio de costo aplicado debe guardar historial por proveedor. |
| RN-88 | Si se aplica un precio de venta sugerido, debe guardarse historial de precio con origen y usuario. |
| RN-89 | El sistema puede sugerir precios por margen y redondeo, pero no debe aplicar cambios masivos sin confirmación explícita. |
| RN-90 | La comparación entre proveedores debe mostrar fecha de última actualización para evitar decidir con listas viejas. |

## Reposición, pedidos y recepción

| ID | Regla |
|---|---|
| RN-91 | La reposición sugerida debe basarse inicialmente en stock ideal menos stock actual. |
| RN-92 | La sugerencia puede usar proveedor habitual o proveedor con mejor costo reciente, pero la decisión final queda en la dueña. |
| RN-93 | Un pedido a proveedor puede pasar por estados borrador, enviado, recibido parcial, recibido y cancelado. |
| RN-94 | La recepción puede ser total o parcial. |
| RN-95 | Toda recepción confirmada debe generar movimientos `INGRESO_COMPRA`. |
| RN-96 | Si el producto requiere vencimiento, la recepción debe cargar lote o fecha de vencimiento. |
| RN-97 | La cantidad recibida no necesariamente debe coincidir con la solicitada, pero la diferencia debe quedar visible. |
| RN-98 | La recepción puede actualizar costo proveedor si corresponde y debe auditarse. |

## Importación y exportación

| ID | Regla |
|---|---|
| RN-99 | Ninguna importación masiva debe persistirse sin validación previa. |
| RN-100 | El sistema debe informar errores por fila o campo antes de confirmar una importación. |
| RN-101 | Una importación no debe sobrescribir datos críticos sin confirmación explícita. |
| RN-102 | Las importaciones deben quedar auditadas con usuario, fecha, archivo y resultado. |
| RN-103 | Las exportaciones deben reflejar el estado de los datos al momento de generarse. |

## Reportes y alertas

| ID | Regla |
|---|---|
| RN-104 | Los reportes deben derivarse de información persistida en backend, no de cálculos manuales aislados en frontend. |
| RN-105 | Los reportes deben respetar permisos de usuario. |
| RN-106 | Las alertas de stock bajo y vencimiento próximo deben generarse según umbrales configurables. |
| RN-107 | Una alerta no debe repetirse excesivamente si la condición base no cambió. |
| RN-108 | Una alerta resuelta debe conservar historial de resolución. |
| RN-109 | Las listas de precios pendientes de revisión deben poder generar tareas o alertas para la administradora. |
| RN-110 | Los productos con etiqueta pendiente deben aparecer en reportes o tareas operativas.

## Auditoría

| ID | Regla |
|---|---|
| RN-111 | La auditoría debe registrar acciones críticas del negocio. |
| RN-112 | Los registros de auditoría no deben ser editables por usuarios comunes. |
| RN-113 | Deben auditarse cambios de precio, ajustes de stock, ventas, anulaciones, ofertas, consumo interno, cierres de caja e importaciones. |
| RN-114 | También deben auditarse cargas de listas, resolución de ítems, aprobación de cambios de costo/precio, pedidos, recepciones y cambios de permisos. |
| RN-115 | La auditoría debe permitir reconstruir quién hizo qué, cuándo y sobre qué entidad. |

## Decisiones de diseño derivadas

| Regla | Impacto técnico |
|---|---|
| RN-05, RN-89 a RN-92 | Módulo de auditoría transversal. |
| RN-15 a RN-25 | Modelo de stock por lote y vencimiento. |
| RN-20 | Servicio de descuento FEFO. |
| RN-32 a RN-41 | Venta con estados y confirmación transaccional. |
| RN-42 a RN-49 | Detalle de venta con precio histórico y motivo de cambio. |
| RN-50 a RN-57 | Entidad OfertaTemporal y regla de prioridad. |
| RN-58 a RN-65 | Módulo de consumo interno separado de ventas y mermas. |
| RN-70 a RN-78 | Caja con movimientos automáticos y manuales. |
| RN-79 a RN-90 | Módulo de proveedores, listas de precios y actualización asistida. |
| RN-91 a RN-98 | Reposición, pedidos y recepción de mercadería. |
| RN-99 a RN-103 | Servicio de importación con preview y validación. |
| RN-104 a RN-110 | Reportes backend y motor de alertas. |

## Observación final

> [!tip]
> Estas reglas deben traducirse luego en validaciones de backend, pruebas unitarias, pruebas de integración y criterios de aceptación de historias de usuario.
