---
title: Casos de uso
aliases:
  - Use cases del sistema
  - Interacciones principales
  - Casos de uso Lembas
tags:
  - tpf
  - casos-de-uso
  - analisis
  - procesos
  - trazabilidad
cssclasses:
  - wide-page
---

# Casos de uso

> [!abstract]
> Casos de uso principales de Lembas, actualizados según [[00 - TPF Dietética Lembas]]. Cubren actores, objetivos, precondiciones, flujos básicos, alternativas y reglas asociadas para los procesos centrales del sistema, incluyendo proveedores, listas de precios, actualización asistida, reposición, pedidos y recepción de mercadería.

## Actores

| Actor | Descripción |
|---|---|
| Administradora/Dueña | Usuario principal con acceso completo a gestión, reportes, caja, configuración y auditoría. |
| Empleado | Usuario operativo con acceso limitado a ventas, consulta de productos, tareas de turno y acciones autorizadas. |
| Sistema | Componente automático que valida, calcula, descuenta stock, registra caja, genera alertas y audita. |

---

# CU-01 Gestionar usuarios y roles

**Actor principal:** Administradora/Dueña  
**Objetivo:** administrar accesos internos y permisos.  
**Prioridad:** Alta

## Precondiciones

- La administradora inició sesión.
- El usuario tiene permiso de gestión de usuarios.

## Flujo básico

1. La administradora ingresa al módulo de usuarios.
2. El sistema muestra usuarios existentes y filtros.
3. La administradora crea o edita un usuario.
4. Asigna rol y estado.
5. El sistema valida datos obligatorios.
6. El sistema guarda la información.
7. El sistema registra auditoría.

## Flujos alternativos

- Si el email ya existe, el sistema informa el error.
- Si se desactiva un usuario, no puede iniciar sesión.
- Si se cambia un rol, el sistema aplica nuevos permisos en el próximo acceso o refresco de sesión.

## Reglas asociadas

- RN-01 a RN-06.

---

# CU-02 Gestionar productos

**Actor principal:** Administradora/Dueña  
**Actor secundario:** Empleado autorizado  
**Objetivo:** mantener actualizado el catálogo de productos.  
**Prioridad:** Alta

## Flujo básico

1. El usuario ingresa al módulo de productos.
2. Busca un producto existente o selecciona crear nuevo.
3. Carga nombre, categoría, marca, presentación, precio, stock mínimo y datos opcionales.
4. Registra código de barras si el producto lo tiene.
5. Asocia proveedor habitual si corresponde.
6. Guarda el producto.
7. El sistema valida datos y persiste.
8. El sistema audita la operación.

## Flujos alternativos

- Si el código de barras ya está asignado a otro producto activo, se rechaza la operación.
- Si el producto tiene historial, la baja debe ser lógica.
- Si cambia el precio, se genera historial de precio.

## Reglas asociadas

- RN-07 a RN-14.

---

# CU-03 Consultar producto por código de barras o búsqueda manual

**Actor principal:** Empleado  
**Objetivo:** consultar rápidamente precio y stock.  
**Prioridad:** Alta

## Flujo básico con scanner

1. El empleado enfoca el campo de búsqueda.
2. Escanea el código de barras.
3. El sistema busca el producto activo.
4. El sistema muestra nombre, precio, stock disponible y vencimientos relevantes.

## Flujo básico manual

1. El empleado escribe nombre, marca, categoría o presentación.
2. El sistema muestra coincidencias.
3. El empleado selecciona el producto.
4. El sistema muestra la ficha resumida.

## Flujos alternativos

- Si no existe producto con ese código, se muestra mensaje de no encontrado.
- Si el producto está inactivo, se informa que no puede operarse.

---

# CU-04 Gestionar proveedores

**Actor principal:** Administradora/Dueña  
**Objetivo:** mantener información de abastecimiento.  
**Prioridad:** Media-Alta

## Flujo básico

1. La administradora ingresa al módulo de proveedores.
2. Crea o edita proveedor.
3. Carga datos de contacto y observaciones.
4. Asocia productos abastecidos.
5. Guarda cambios.
6. El sistema persiste y audita.

## Flujos alternativos

- Si el proveedor deja de operar, se desactiva sin eliminar historial.
- Si un producto tiene varios proveedores, se puede marcar uno como habitual.

---

# CU-05 Registrar ingreso de stock

**Actor principal:** Administradora/Dueña o empleado autorizado  
**Objetivo:** sumar mercadería disponible.  
**Prioridad:** Alta

## Flujo básico

1. El usuario selecciona producto.
2. Carga cantidad recibida.
3. Indica vencimiento o lote si corresponde.
4. Selecciona proveedor u origen.
5. Confirma ingreso.
6. El sistema crea lote o actualiza lote existente según criterio definido.
7. El sistema registra movimiento `INGRESO_COMPRA`.
8. El sistema audita la operación.

## Flujos alternativos

- Si falta vencimiento en un producto que lo requiere, se rechaza la carga.
- Si la cantidad es menor o igual a cero, se rechaza la operación.

---

# CU-06 Registrar ajuste, merma o vencimiento

**Actor principal:** Administradora/Dueña o empleado autorizado  
**Objetivo:** reflejar salidas o correcciones de stock que no son ventas.  
**Prioridad:** Alta

## Flujo básico

1. El usuario selecciona producto.
2. Selecciona tipo de movimiento: merma, vencimiento, ajuste positivo o ajuste negativo.
3. Indica cantidad.
4. Indica motivo.
5. Confirma.
6. El sistema valida stock disponible cuando corresponde.
7. El sistema registra movimiento de stock.
8. El sistema audita.

## Flujos alternativos

- Si es vencimiento, se solicita lote o fecha afectada.
- Si no hay stock suficiente, se impide el egreso salvo permiso excepcional.

---

# CU-07 Registrar venta mostrador simplificada

**Actor principal:** Empleado  
**Actor secundario:** Administradora/Dueña  
**Objetivo:** registrar una venta simple, descontar stock y generar ingreso de caja.  
**Prioridad:** Alta

## Precondiciones

- El usuario inició sesión.
- Los productos están activos.
- Existe stock disponible.
- La caja o turno está abierto si la configuración lo requiere.

## Flujo básico

1. El empleado selecciona `Nueva venta`.
2. El sistema crea una venta en estado borrador.
3. El empleado escanea un producto.
4. El sistema busca el producto por código de barras.
5. El sistema agrega el producto al detalle.
6. El sistema verifica si existe oferta activa.
7. El sistema calcula subtotal y total.
8. El empleado repite la carga para otros productos.
9. El empleado confirma la venta.
10. El sistema valida stock y permisos.
11. El sistema descuenta stock por FEFO.
12. El sistema registra movimiento de stock `EGRESO_VENTA`.
13. El sistema registra ingreso automático de caja.
14. El sistema marca la venta como confirmada.
15. El sistema audita la operación.

## Flujos alternativos

- Producto sin código de barras: el empleado busca manualmente.
- Stock insuficiente: el sistema impide confirmar o solicita permiso excepcional.
- Oferta activa: el sistema aplica o sugiere precio promocional.
- Caja cerrada: el sistema impide confirmar si la configuración exige caja abierta.

## Postcondiciones

- La venta queda confirmada.
- El stock queda descontado.
- La caja queda actualizada.
- El precio aplicado queda guardado históricamente.

---

# CU-08 Modificar cantidad en venta

**Actor principal:** Empleado  
**Objetivo:** ajustar cantidades antes de confirmar la venta.  
**Prioridad:** Alta

## Flujo básico

1. El empleado selecciona una línea de venta.
2. Modifica la cantidad.
3. El sistema valida que sea mayor que cero.
4. El sistema recalcula subtotal y total.
5. La venta continúa en borrador hasta confirmarse.

## Reglas asociadas

- No se descuenta stock hasta confirmar.
- No se debe permitir vender más de lo disponible salvo permiso excepcional.

---

# CU-09 Modificar precio en venta

**Actor principal:** Administradora/Dueña o empleado autorizado  
**Objetivo:** aplicar una excepción controlada de precio.  
**Prioridad:** Media-Alta

## Flujo básico

1. El usuario selecciona una línea de venta.
2. Ingresa nuevo precio aplicado.
3. Indica motivo.
4. El sistema valida permisos o límites configurados.
5. El sistema recalcula subtotal y total.
6. El sistema registra auditoría del cambio.

## Flujos alternativos

- Si el usuario no tiene permiso, el sistema rechaza la modificación.
- Si no se indica motivo, el sistema no permite guardar.

---

# CU-10 Anular venta

**Actor principal:** Administradora/Dueña  
**Objetivo:** revertir una venta de forma controlada.  
**Prioridad:** Media

## Flujo básico

1. La administradora busca la venta.
2. Selecciona anular.
3. Ingresa motivo.
4. El sistema valida estado de la venta.
5. El sistema registra anulación o movimientos compensatorios según diseño.
6. El sistema actualiza caja si corresponde.
7. El sistema audita.

## Regla clave

La venta no debe eliminarse físicamente.

---

# CU-11 Gestionar ofertas temporales

**Actor principal:** Administradora/Dueña  
**Objetivo:** definir promociones por producto y rango de fechas.  
**Prioridad:** Media

## Flujo básico

1. La administradora ingresa al módulo de ofertas.
2. Selecciona producto.
3. Define tipo de oferta: porcentaje o precio fijo.
4. Carga fecha de inicio y fin.
5. Guarda oferta.
6. El sistema valida fechas y estado.
7. El sistema audita.

## Flujos alternativos

- Si la fecha de fin es anterior a inicio, se rechaza.
- Si existe otra oferta vigente, se aplica regla de prioridad o se advierte.

---

# CU-12 Registrar consumo interno

**Actor principal:** Empleado o Administradora/Dueña  
**Objetivo:** registrar consumo de productos sin tratarlo como venta.  
**Prioridad:** Media-Alta

## Flujo básico

1. El usuario inicia un consumo interno.
2. Selecciona producto.
3. Indica cantidad.
4. Selecciona razón.
5. Confirma.
6. El sistema valida stock.
7. El sistema descuenta stock por FEFO.
8. El sistema registra movimiento `CONSUMO_INTERNO`.
9. El sistema audita.

## Flujos alternativos

- Si requiere aprobación, queda pendiente hasta que la administradora lo apruebe.
- Si la razón es `OTRO`, se exige descripción.

## Postcondición

No se genera movimiento de caja.

---

# CU-13 Operar caja

**Actor principal:** Empleado o Administradora/Dueña  
**Objetivo:** registrar ingresos y egresos operativos.  
**Prioridad:** Alta

## Flujo básico

1. El usuario abre caja o turno con saldo inicial.
2. Registra ingresos o egresos manuales si corresponde.
3. Las ventas confirmadas generan ingresos automáticos.
4. El usuario consulta movimientos.
5. El sistema muestra saldo esperado.

## Flujos alternativos

- Si se intenta registrar egreso sin concepto, se rechaza.
- Si una venta genera ingreso automático, queda relacionada a la venta.

---

# CU-14 Cerrar turno o caja diaria

**Actor principal:** Empleado o Administradora/Dueña  
**Objetivo:** cerrar el período operativo y registrar diferencias.  
**Prioridad:** Alta

## Flujo básico

1. El usuario solicita cierre.
2. El sistema muestra resumen de movimientos.
3. El usuario ingresa saldo contado.
4. El sistema calcula diferencia.
5. El usuario agrega observaciones si corresponde.
6. El sistema confirma cierre.
7. El sistema audita.

## Flujos alternativos

- Si hay diferencia, se registra para análisis.
- Si el cierre ya fue confirmado, solo administradora puede corregir con auditoría.

---

# CU-15 Generar etiquetas o listados de precios

**Actor principal:** Administradora/Dueña o empleado autorizado  
**Objetivo:** imprimir precios actualizados para mostrador.  
**Prioridad:** Media

## Flujo básico

1. El usuario selecciona productos o filtros.
2. El sistema genera vista previa.
3. El usuario confirma impresión o exportación.
4. El sistema genera PDF/HTML imprimible.
5. El sistema registra historial si corresponde.

---

# CU-16 Cargar lista de precios de proveedor

**Actor principal:** Administradora/Dueña  
**Objetivo:** incorporar costos enviados por proveedores para revisarlos antes de aplicarlos.  
**Prioridad:** Alta

## Flujo básico

1. La administradora selecciona un proveedor.
2. Elige método de carga: Excel, texto de WhatsApp o manual.
3. Carga el archivo, pega el texto o ingresa los datos.
4. El sistema normaliza los ítems detectados.
5. El sistema intenta reconocer productos internos.
6. El sistema clasifica cada ítem según su estado de reconocimiento.
7. La lista queda disponible para revisión.
8. El sistema audita la carga.

## Flujos alternativos

- Si el archivo Excel no respeta la estructura mínima, se informa el error.
- Si el texto de WhatsApp contiene líneas ambiguas, se marcan para revisión.
- Si un ítem no se reconoce, puede resolverse manualmente, crearse como producto nuevo o ignorarse.

## Fuera de alcance

No se contempla lectura automática de PDF, imágenes, fotos, OCR, audio ni catálogos web.

---

# CU-17 Revisar y aplicar cambios de costo/precio

**Actor principal:** Administradora/Dueña  
**Objetivo:** comparar costos nuevos contra anteriores y aplicar cambios aprobados.  
**Prioridad:** Alta

## Flujo básico

1. La administradora abre una lista en revisión.
2. El sistema muestra producto, proveedor, costo anterior, costo nuevo y diferencia porcentual.
3. La administradora resuelve ítems dudosos.
4. El sistema calcula precio de venta sugerido según margen y redondeo.
5. La administradora decide si solo actualiza costo o también precio de venta.
6. La administradora confirma los cambios seleccionados.
7. El sistema actualiza costo proveedor e historial.
8. El sistema actualiza precios de venta aprobados.
9. El sistema marca etiquetas pendientes cuando corresponde.
10. El sistema audita la aplicación.

## Flujos alternativos

- La lista puede descartarse sin aplicar cambios.
- Los ítems no reconocidos pueden ignorarse.
- Los precios sugeridos pueden revisarse manualmente antes de aplicar.

---

# CU-18 Comparar proveedores y generar reposición sugerida

**Actor principal:** Administradora/Dueña  
**Objetivo:** decidir reposición considerando stock y costos recientes.  
**Prioridad:** Media-Alta

## Flujo básico

1. La administradora consulta productos bajo stock mínimo.
2. El sistema calcula cantidad sugerida como stock ideal menos stock actual.
3. El sistema identifica proveedor habitual o proveedor con mejor costo reciente.
4. El sistema agrupa sugerencias por proveedor.
5. La administradora revisa y ajusta cantidades.
6. Opcionalmente genera un pedido borrador.

## Reglas asociadas

- La sugerencia no reemplaza la decisión de compra de la dueña.
- Las listas viejas deben advertirse para no comparar costos desactualizados.

---

# CU-19 Gestionar pedido a proveedor

**Actor principal:** Administradora/Dueña  
**Objetivo:** organizar pedidos de reposición.  
**Prioridad:** Media

## Flujo básico

1. La administradora crea un pedido borrador manualmente o desde reposición sugerida.
2. Selecciona proveedor.
3. Agrega productos, cantidades y costo esperado.
4. Guarda el pedido.
5. Cuando corresponde, lo marca como enviado.
6. El sistema audita cambios de estado.

## Estados

- `BORRADOR`;
- `ENVIADO`;
- `RECIBIDO_PARCIAL`;
- `RECIBIDO`;
- `CANCELADO`.

---

# CU-20 Registrar recepción de mercadería

**Actor principal:** Administradora/Dueña o empleado autorizado  
**Objetivo:** registrar lo recibido, actualizar stock y cargar vencimientos.  
**Prioridad:** Media-Alta

## Flujo básico

1. El usuario selecciona un pedido o inicia recepción manual.
2. Ingresa cantidades recibidas.
3. Carga lote y vencimiento cuando corresponde.
4. Confirma recepción.
5. El sistema actualiza stock.
6. El sistema registra movimientos `INGRESO_COMPRA`.
7. El sistema actualiza costo proveedor si corresponde.
8. El sistema audita la recepción.

## Flujos alternativos

- Puede recibirse solo parte del pedido.
- La cantidad recibida puede diferir de la solicitada y debe quedar visible.
- Si falta vencimiento en un producto que lo requiere, se rechaza la confirmación.

---

# CU-21 Importar y exportar información

**Actor principal:** Administradora/Dueña  
**Objetivo:** migrar, actualizar o extraer información.  
**Prioridad:** Media

## Flujo de importación

1. La administradora selecciona archivo o fuente permitida.
2. El sistema valida estructura.
3. El sistema muestra errores por fila si existen.
4. La administradora confirma procesamiento.
5. El sistema persiste datos válidos.
6. El sistema audita resultado.

## Flujo de exportación

1. La administradora selecciona tipo de exportación.
2. Aplica filtros.
3. El sistema genera archivo.
4. El archivo queda disponible para descarga.

---

# CU-22 Consultar reportes

**Actor principal:** Administradora/Dueña  
**Objetivo:** obtener información operativa para decisiones.  
**Prioridad:** Media

## Reportes incluidos

- stock actual;
- stock bajo;
- vencimientos próximos;
- ventas por día o turno;
- movimientos de caja;
- consumo interno;
- mermas;
- ofertas vigentes;
- proveedores;
- listas de precios importadas;
- cambios de costo y precio;
- comparación de costos por proveedor;
- etiquetas pendientes;
- pedidos y recepciones.

---

# CU-23 Recibir alertas operativas

**Actor principal:** Sistema  
**Objetivo:** avisar condiciones que requieren atención.  
**Prioridad:** Media

## Ejemplos

- producto con stock bajo;
- lote próximo a vencer;
- cierre de caja pendiente;
- importación con errores;
- lista de precios pendiente de revisión;
- producto con etiqueta pendiente;
- producto recomendado para reposición.

---

# CU-24 Consultar panel según rol

**Actor principal:** Administradora/Dueña o Empleado  
**Objetivo:** visualizar información adecuada al rol.  
**Prioridad:** Alta

## Panel de administradora

Debe mostrar:

- ventas del día;
- caja actual;
- stock bajo;
- próximos vencimientos;
- reposición sugerida;
- últimas ventas;
- reportes;
- listas de precios pendientes;
- etiquetas pendientes;
- pedidos y recepciones;
- accesos administrativos.

## Panel de empleado

Debe mostrar:

- botón principal de nueva venta;
- ventas del turno;
- productos a revisar;
- tareas pendientes;
- últimas ventas propias;
- estado del turno;
- cierre de turno.

## Restricciones

El empleado no debe ver reportes globales, márgenes, costos, listas completas de proveedores, importaciones masivas, auditoría completa ni configuración avanzada salvo permiso explícito.

---

# Prioridad resumida

| Caso | Prioridad |
|---|---|
| CU-01 Usuarios y roles | Alta |
| CU-02 Productos | Alta |
| CU-03 Consulta por scanner/manual | Alta |
| CU-05 Ingreso de stock | Alta |
| CU-06 Ajuste/merma/vencimiento | Alta |
| CU-07 Venta mostrador | Alta |
| CU-08 Modificar cantidad | Alta |
| CU-09 Modificar precio | Media-Alta |
| CU-12 Consumo interno | Media-Alta |
| CU-13 Caja | Alta |
| CU-14 Cierre | Alta |
| CU-15 Etiquetas | Media |
| CU-16 Cargar lista de precios | Alta |
| CU-17 Revisar costos/precios | Alta |
| CU-18 Reposición sugerida | Media-Alta |
| CU-19 Pedido proveedor | Media |
| CU-20 Recepción mercadería | Media-Alta |
| CU-21 Importación/exportación | Media |
| CU-22 Reportes | Media |
| CU-23 Alertas | Media |
| CU-24 Panel por rol | Alta |
