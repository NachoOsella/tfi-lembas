---
title: Plan de sprints
aliases:
  - Roadmap iterativo
  - Sprints del TPF
  - Plan de implementación Lembas
tags:
  - tpf
  - sprints
  - scrum
  - roadmap
  - planificacion
cssclasses:
  - wide-page
---

# Plan de sprints

> [!abstract]
> Plan de implementación iterativo para Lembas, alineado con [[00 - TPF Dietética Lembas]]. La planificación prioriza una demo sólida de punta a punta: seguridad, productos, proveedores, listas de precios, stock por vencimiento, venta mostrador con scanner, caja, consumo interno, ofertas, actualización asistida de precios, reportes, auditoría y despliegue.

## Criterio de planificación

La planificación está pensada para un TPF realista y defendible. Se prioriza construir primero la base técnica y luego cerrar circuitos funcionales completos.

Criterios principales:

1. construir una arquitectura base mantenible;
2. implementar roles y seguridad desde el inicio;
3. modelar productos y stock antes de vender;
4. integrar venta, stock y caja de forma transaccional;
5. agregar proveedores, listas de precios y actualización asistida como valor diferencial;
6. agregar ofertas, consumo interno y etiquetas como valor operativo;
7. cerrar con reportes, auditoría, pruebas y despliegue.

## Resumen ejecutivo

| Sprint | Duración | Objetivo principal | Entregable visible |
|---|---:|---|---|
| Sprint 1 | 2 semanas | Base técnica, seguridad y UI inicial | Login, roles, home admin/empleado y arquitectura base |
| Sprint 2 | 2 semanas | Catálogo, proveedores, listas y stock | Productos, códigos de barras, ProductoProveedor, listas, lotes y vencimientos |
| Sprint 3 | 2 semanas | Venta mostrador, caja, ofertas, consumo interno y precios | Flujo de venta con scanner, descuento FEFO, caja y actualización asistida |
| Sprint 4 | 2 semanas | Reposición, recepción, reportes, etiquetas, auditoría, QA y despliegue | Sistema integrado, documentado, testeado y desplegable |

---

# Sprint 1 - Base técnica, seguridad y experiencia inicial

## Objetivo del sprint

Crear la base del sistema con frontend, backend, base de datos, autenticación, roles y navegación inicial diferenciada para administradora y empleado.

## Epic 1.1 - Fundación técnica

### User Story 1.1.1

**Como** equipo de desarrollo, **quiero** inicializar frontend, backend y base de datos, **para** desarrollar sobre una estructura ordenada.

**Tareas**

- Crear proyecto Spring Boot.
- Crear proyecto Angular.
- Configurar PostgreSQL local.
- Configurar Docker Compose de desarrollo.
- Definir estructura por módulos.
- Configurar perfiles de entorno.
- Configurar CORS o proxy local.
- Documentar cómo levantar el proyecto.

**Criterios de aceptación**

- El backend inicia sin errores.
- El frontend inicia sin errores.
- La base de datos está accesible.
- Existe endpoint de health o prueba.
- El frontend puede consumir el backend en desarrollo.

### User Story 1.1.2

**Como** responsable técnico, **quiero** una arquitectura modular, **para** que el sistema sea mantenible.

**Tareas**

- Definir capas: presentación, aplicación, dominio e infraestructura.
- Crear paquetes por módulo.
- Definir DTOs y convenciones.
- Configurar migraciones con Flyway o Liquibase.
- Crear documentación de arquitectura.

**DoD del epic**

- Estructura base creada.
- Convenciones documentadas.
- Sin dependencias circulares evidentes.
- Migración inicial ejecutable.

## Epic 1.2 - Seguridad, usuarios y roles

### User Story 1.2.1

**Como** usuario interno, **quiero** iniciar sesión, **para** acceder al sistema de forma segura.

**Tareas**

- Entidad Usuario.
- Entidad Rol.
- Hash de contraseña.
- Endpoint de login.
- Generación y validación de JWT o sesión segura.
- Manejo de errores de autenticación.

**Criterios de aceptación**

- Credenciales válidas permiten ingresar.
- Credenciales inválidas son rechazadas.
- Usuarios inactivos no pueden operar.
- El token o sesión identifica rol y usuario.

### User Story 1.2.2

**Como** administradora, **quiero** gestionar usuarios, **para** controlar accesos del personal.

**Tareas**

- CRUD de usuarios.
- Baja lógica.
- Roles administradora y empleado.
- Validaciones básicas.
- Auditoría de cambios.

### User Story 1.2.3

**Como** sistema, **quiero** restringir acciones por rol, **para** proteger información sensible.

**Tareas**

- Guardas de rutas en Angular.
- Autorización por endpoint en Spring Security.
- Menú dinámico por rol.
- Ocultar reportes sensibles a empleados.

## Epic 1.3 - UI inicial y mockups funcionales

### User Story 1.3.1

**Como** administradora, **quiero** un panel inicial, **para** ver indicadores principales del negocio.

**Tareas**

- Layout base.
- Home admin.
- Cards de ventas del día, caja, stock bajo y vencimientos.
- Accesos a productos, stock, caja y reportes.

### User Story 1.3.2

**Como** empleado, **quiero** una pantalla simple de turno, **para** acceder rápido a venta y tareas.

**Tareas**

- Home empleado.
- Botón principal `Nueva venta`.
- Acceso a consulta de productos.
- Estado de turno.
- Tareas o alertas operativas.

## DoD Sprint 1

- Login funcional.
- Roles administradora y empleado operativos.
- Rutas y endpoints protegidos.
- Homes diferenciados.
- Base de datos versionada.
- Arquitectura documentada.
- Proyecto levantable en local.

---

# Sprint 2 - Catálogo, proveedores, listas, stock y vencimientos

## Objetivo del sprint

Construir el núcleo de inventario y abastecimiento: productos, proveedores, mapeo ProductoProveedor, listas de precios, lotes, movimientos de stock, vencimientos y alertas iniciales.

## Epic 2.1 - Productos y catálogo

### User Story 2.1.1

**Como** administradora, **quiero** crear y editar productos, **para** mantener el catálogo actualizado.

**Tareas**

- Entidad Producto.
- CRUD de productos.
- Validaciones de nombre, precio y estado.
- Código de barras opcional.
- Restricción de código de barras único en activos.
- Búsqueda por nombre, código, categoría y marca.

### User Story 2.1.2

**Como** usuario interno, **quiero** clasificar productos, **para** organizar mejor el catálogo.

**Tareas**

- Categorías.
- Marcas.
- Presentación.
- Filtros y paginación.
- Vista responsive.

### User Story 2.1.3

**Como** usuario de mostrador, **quiero** consultar precio y stock, **para** responder rápido durante la atención.

**Tareas**

- Vista rápida de producto.
- Consulta por scanner.
- Consulta manual.
- Stock disponible total.
- Lotes próximos a vencer.

## Epic 2.2 - Proveedores

### User Story 2.2.1

**Como** administradora, **quiero** administrar proveedores, **para** centralizar abastecimiento.

**Tareas**

- Entidad Proveedor.
- CRUD con baja lógica.
- Datos de contacto.
- Búsqueda y filtros.

### User Story 2.2.2

**Como** administradora, **quiero** asociar productos con proveedores, **para** saber quién abastece cada producto.

**Tareas**

- Relación ProductoProveedor.
- Proveedor habitual.
- Proveedores alternativos.
- Nombre, código y presentación según proveedor.
- Último costo por proveedor.
- Consulta desde ficha de producto.

## Epic 2.3 - Listas de precios de proveedor

### User Story 2.3.1

**Como** administradora, **quiero** cargar listas de precios desde Excel, **para** actualizar costos sin carga manual completa.

**Tareas**

- Entidad ListaPrecioProveedor.
- Entidad ItemListaPrecioProveedor.
- Carga de archivo Excel.
- Validación de columnas mínimas.
- Estados de lista.
- Auditoría de carga.

### User Story 2.3.2

**Como** administradora, **quiero** pegar listas copiadas desde WhatsApp, **para** procesar proveedores que envían precios por mensaje.

**Tareas**

- Pantalla de pegado de texto.
- Parser simple por líneas.
- Detección de nombre y costo.
- Marcado de líneas ambiguas.
- Revisión manual.

### User Story 2.3.3

**Como** administradora, **quiero** mapear ítems de lista con productos internos, **para** normalizar nombres distintos entre proveedores.

**Tareas**

- Estados de reconocimiento.
- Resolución manual.
- Asociación con ProductoProveedor.
- Ignorar ítems no aplicables.

> [!warning]
> PDF, imágenes, OCR, audio e IA generativa quedan fuera de este sprint y del MVP.

## Epic 2.4 - Stock, lotes y vencimientos

### User Story 2.4.1

**Como** encargado, **quiero** registrar ingresos de stock, **para** reflejar mercadería recibida.

**Tareas**

- Entidad LoteStock.
- Movimiento `INGRESO_COMPRA`.
- Cantidad y vencimiento.
- Proveedor asociado.
- Usuario responsable.

### User Story 2.4.2

**Como** encargado, **quiero** registrar egresos no vinculados a venta, **para** controlar mermas y vencimientos.

**Tareas**

- Movimiento `MERMA`.
- Movimiento `VENCIMIENTO`.
- Ajustes positivos y negativos.
- Motivo obligatorio.
- Validación de stock disponible.

### User Story 2.4.3

**Como** administradora, **quiero** ver stock por vencimiento, **para** retirar o priorizar productos próximos a vencer.

**Tareas**

- Listado de lotes por producto.
- Filtros por fecha de vencimiento.
- Indicadores de próximos vencimientos.
- Consulta FEFO preparada.

### User Story 2.4.4

**Como** usuario interno, **quiero** registrar inventario físico, **para** comparar el stock real con el teórico.

**Tareas**

- Entidad InventarioFisico.
- Detalles por producto/lote.
- Diferencia calculada.
- Observaciones.
- Posible generación de ajuste.

## DoD Sprint 2

- Productos cargables, editables y consultables.
- Código de barras funcional para búsqueda.
- Proveedores y relaciones operativas.
- ProductoProveedor con nombres/códigos de proveedor.
- Carga inicial de listas por Excel, WhatsApp o manual.
- Ítems de lista revisables.
- Stock por lote y vencimiento.
- Movimientos de stock auditables.
- Alertas iniciales de bajo stock o vencimiento.
- UI usable en móvil.

---

# Sprint 3 - Venta mostrador, ofertas, consumo interno, caja y pricing

## Objetivo del sprint

Implementar el circuito operativo central: registrar venta con scanner, aplicar reglas de precio, descontar stock por FEFO, generar caja, registrar consumos internos y aplicar actualización asistida de costos/precios.

## Epic 3.1 - Venta mostrador simplificada

### User Story 3.1.1

**Como** empleado, **quiero** iniciar una venta mostrador, **para** registrar productos vendidos.

**Tareas**

- Entidad Venta.
- Entidad DetalleVenta.
- Estado borrador/confirmada/anulada.
- Pantalla de nueva venta mobile-first.
- Campo preparado para scanner.

### User Story 3.1.2

**Como** empleado, **quiero** escanear productos, **para** agregarlos rápidamente a la venta.

**Tareas**

- Búsqueda por código de barras.
- Agregado automático al detalle.
- Incremento de cantidad si el producto ya está en la venta.
- Mensaje si no se encuentra el código.

### User Story 3.1.3

**Como** empleado, **quiero** buscar productos manualmente, **para** vender productos sin código de barras.

**Tareas**

- Buscador por nombre, marca, categoría y presentación.
- Selector de producto.
- Agregado a venta.

### User Story 3.1.4

**Como** empleado, **quiero** modificar cantidad, **para** registrar correctamente unidades vendidas.

**Tareas**

- Edición de cantidad.
- Validación mayor que cero.
- Validación de stock.
- Recalcular subtotales.

### User Story 3.1.5

**Como** usuario autorizado, **quiero** modificar precio con motivo, **para** resolver excepciones de mostrador.

**Tareas**

- Permiso de modificación de precio.
- Campo de motivo obligatorio.
- Registro de precio base y precio aplicado.
- Auditoría del cambio.

### User Story 3.1.6

**Como** empleado, **quiero** confirmar la venta, **para** descontar stock y registrar caja.

**Tareas**

- Validación final de stock.
- Descuento FEFO.
- Movimientos `EGRESO_VENTA`.
- Movimiento de caja `INGRESO_VENTA`.
- Transacción atómica.
- Auditoría.

## Epic 3.2 - Ofertas temporales

### User Story 3.2.1

**Como** administradora, **quiero** crear ofertas temporales, **para** aplicar promociones controladas.

**Tareas**

- Entidad OfertaTemporal.
- Tipo porcentaje o precio fijo.
- Fecha inicio y fin.
- Estado activo/inactivo.
- Validaciones de fechas.

### User Story 3.2.2

**Como** sistema, **quiero** aplicar ofertas vigentes en venta, **para** calcular el precio correcto.

**Tareas**

- Detección de oferta activa.
- Regla de prioridad si hay más de una.
- Registro de oferta en DetalleVenta.
- Visualización de precio base y promocional.

## Epic 3.3 - Consumo interno

### User Story 3.3.1

**Como** empleado, **quiero** registrar consumo interno, **para** justificar productos consumidos en el local.

**Tareas**

- Entidad ConsumoInterno.
- Detalle de consumo.
- Razón de consumo.
- Validación de stock.
- Descuento FEFO.
- Movimiento `CONSUMO_INTERNO`.
- Auditoría.

### User Story 3.3.2

**Como** administradora, **quiero** aprobar consumos si corresponde, **para** controlar su uso.

**Tareas**

- Estado pendiente/aprobado/rechazado opcional.
- Permisos de aprobación.
- Registro de usuario aprobador.

## Epic 3.4 - Actualización asistida de precios

### User Story 3.4.1

**Como** administradora, **quiero** comparar costo anterior y costo nuevo, **para** decidir si aplico cambios.

**Tareas**

- HistorialCostoProveedor.
- Comparación porcentual.
- Vista de revisión de lista.
- Acciones aplicar/ignorar/crear producto.

### User Story 3.4.2

**Como** administradora, **quiero** configurar margen y redondeo, **para** obtener precios sugeridos.

**Tareas**

- Entidad ReglaPrecio.
- Margen por categoría o producto.
- Tipo de redondeo.
- Cálculo de precio sugerido.

### User Story 3.4.3

**Como** administradora, **quiero** aplicar cambios seleccionados, **para** actualizar costos y precios con control.

**Tareas**

- Aplicación transaccional.
- HistorialPrecioVenta.
- Marcar etiquetaPendiente.
- Auditoría de aprobación.

## Epic 3.5 - Caja y cierres

### User Story 3.5.1

**Como** empleado, **quiero** abrir turno o caja, **para** iniciar operaciones del día.

**Tareas**

- Entidad TurnoCaja.
- Saldo inicial.
- Estado abierto/cerrado.
- Validación de caja duplicada si aplica.

### User Story 3.5.2

**Como** sistema, **quiero** registrar ingresos por venta automáticamente, **para** mantener caja alineada con ventas.

**Tareas**

- MovimientoCaja `INGRESO_VENTA`.
- Relación con Venta.
- Inclusión en saldo esperado.

### User Story 3.5.3

**Como** usuario autorizado, **quiero** registrar ingresos y egresos manuales, **para** controlar movimientos no vinculados a ventas.

**Tareas**

- Tipos de movimiento.
- Concepto obligatorio.
- Observaciones.
- Historial por fecha y usuario.

### User Story 3.5.4

**Como** administradora o empleado autorizado, **quiero** cerrar turno/caja, **para** comparar saldo esperado y contado.

**Tareas**

- Cálculo de saldo esperado.
- Carga de saldo contado.
- Diferencia.
- Observaciones.
- Auditoría de cierre.

## DoD Sprint 3

- Venta con scanner funcional.
- Búsqueda manual funcional.
- Cantidad editable con validaciones.
- Precio modificable solo con permiso y motivo.
- Ofertas vigentes aplicables.
- Stock descontado por FEFO al confirmar venta.
- Caja actualizada por venta.
- Consumo interno descuenta stock sin impactar caja.
- Cierres de turno o caja funcionales.
- Listas de precios aplicables con aprobación.
- Historial de costo y precio registrado.
- Etiquetas pendientes generadas ante cambios.
- Procesos críticos auditados.

---

# Sprint 4 - Reposición, recepción, reportes, etiquetas, QA, documentación y despliegue

## Objetivo del sprint

Consolidar el sistema, completar reposición sugerida y recepción básica, agregar reportes y exportaciones, reforzar pruebas y preparar despliegue en nube.

## Epic 4.1 - Reposición, pedidos y recepción

### User Story 4.1.1

**Como** administradora, **quiero** ver reposición sugerida, **para** identificar productos a comprar.

**Tareas**

- Cálculo stock ideal menos stock actual.
- Agrupación por proveedor.
- Advertencia de costos desactualizados.
- Generación opcional de pedido borrador.

### User Story 4.1.2

**Como** administradora, **quiero** registrar recepción de mercadería, **para** actualizar stock y vencimientos.

**Tareas**

- PedidoProveedor y DetallePedidoProveedor.
- RecepcionMercaderia.
- Recepción parcial o total.
- Lotes y vencimientos.
- Movimientos `INGRESO_COMPRA`.
- Auditoría.

## Epic 4.2 - Reportes y alertas

### User Story 4.2.1

**Como** administradora, **quiero** consultar reportes operativos, **para** tomar decisiones.

**Tareas**

- Reporte de stock actual.
- Reporte de stock bajo.
- Reporte de vencimientos próximos.
- Reporte de ventas por día/turno.
- Reporte de caja.
- Reporte de consumo interno y mermas.
- Reporte de listas importadas.
- Reporte de cambios de costo/precio.
- Reporte de etiquetas pendientes.
- Reporte de pedidos y recepciones.

### User Story 4.2.2

**Como** sistema, **quiero** generar alertas operativas, **para** anticipar problemas.

**Tareas**

- Alertas de stock bajo.
- Alertas de vencimiento próximo.
- Alertas de cierre pendiente.
- Alertas de listas pendientes de revisión.
- Alertas de etiquetas pendientes.
- Estado leída/resuelta.
- Anti-duplicación simple.

## Epic 4.3 - Etiquetas, precios e impresión

### User Story 4.3.1

**Como** usuario autorizado, **quiero** generar etiquetas, **para** mantener precios visibles en mostrador.

**Tareas**

- Selección de productos.
- Filtro por categoría o cambios recientes.
- Vista previa.
- Exportación PDF/HTML imprimible.

### User Story 4.3.2

**Como** administradora, **quiero** consultar historial de precios, **para** entender cambios y corregir etiquetas.

**Tareas**

- HistorialPrecio.
- Filtros por producto y fecha.
- Relación con usuario responsable.

## Epic 4.4 - Importación y exportación

### User Story 4.4.1

**Como** administradora, **quiero** importar productos, stock, precios o listas desde fuentes permitidas, **para** reducir carga manual.

**Tareas**

- Parsing de XLSX/CSV.
- Carga textual desde WhatsApp ya normalizada.
- Validación de columnas.
- Preview de errores.
- Confirmación de importación.
- Registro de incidencias.

### User Story 4.4.2

**Como** administradora, **quiero** exportar información, **para** analizarla o compartirla.

**Tareas**

- Exportación de productos.
- Exportación de stock.
- Exportación de ventas.
- Exportación de caja.
- Exportación de reportes.

## Epic 4.5 - Auditoría y hardening

### User Story 4.5.1

**Como** administradora, **quiero** consultar auditoría, **para** revisar acciones críticas.

**Tareas**

- Entidad Auditoria.
- Registro transversal.
- Filtros por usuario, entidad y fecha.
- Vista solo para rol autorizado.

### User Story 4.5.2

**Como** equipo de desarrollo, **quiero** reforzar validaciones y pruebas, **para** reducir errores.

**Tareas**

- Tests unitarios de servicios críticos.
- Tests de confirmación de venta.
- Tests de descuento FEFO.
- Tests de caja.
- Tests de listas de precios.
- Tests de aplicación asistida de precios.
- Tests de recepción de mercadería.
- Tests de permisos.
- Manejo centralizado de excepciones.

## Epic 4.6 - Despliegue y documentación final

### User Story 4.6.1

**Como** responsable del proyecto, **quiero** desplegar el sistema, **para** presentar una versión accesible.

**Tareas**

- Dockerfile backend.
- Build Angular.
- Nginx reverse proxy.
- Variables de entorno.
- Configuración productiva.
- Backup básico de PostgreSQL.

### User Story 4.6.2

**Como** evaluador, **quiero** documentación consistente, **para** comprender alcance, arquitectura y decisiones.

**Tareas**

- Actualizar notas de Obsidian.
- Revisar requisitos y reglas.
- Incorporar diagramas.
- Matriz de trazabilidad.
- Manual breve de uso.
- Guion de demo.

## DoD Sprint 4

- Reposición sugerida básica funcionando.
- Recepción de mercadería básica funcionando.
- Reportes básicos funcionando.
- Alertas visibles.
- Etiquetas/listados generables.
- Importación/exportación validada.
- Listas de precios aplicables con revisión humana.
- Etiquetas pendientes visibles.
- Auditoría consultable.
- Tests críticos ejecutados.
- Sistema dockerizado o preparado para despliegue.
- Documentación final consistente.
- Demo de punta a punta lista.

---

# Definition of Done general

Una funcionalidad se considera terminada cuando cumple:

- implementada en backend cuando corresponde;
- implementada en frontend cuando corresponde;
- validada por reglas de negocio;
- persistida en PostgreSQL;
- protegida por permisos;
- auditada si es una acción sensible;
- probada con escenarios principales;
- usable en desktop y móvil;
- documentada en Obsidian o README técnico;
- sin errores críticos conocidos.

## Dependencias entre sprints

| Sprint | Depende de | Motivo |
|---|---|---|
| Sprint 1 | Ninguno | Base técnica y seguridad. |
| Sprint 2 | Sprint 1 | Requiere usuarios, roles y estructura. |
| Sprint 3 | Sprint 2 | Venta y consumo requieren productos y stock. |
| Sprint 4 | Sprint 1, 2 y 3 | Reportes, auditoría y despliegue consolidan todo. |

## Riesgos de planificación

| Riesgo | Mitigación |
|---|---|
| Alcance demasiado amplio | Priorizar MVP y dejar mejoras en roadmap. |
| Venta complica stock y caja | Implementar venta simplificada, no POS fiscal. |
| FEFO agrega complejidad | Encapsular lógica en servicio de stock. |
| Modificación de precio puede ser riesgosa | Permisos, motivo y auditoría. |
| Excel puede consumir mucho tiempo | Implementar importación acotada con validación mínima sólida. |
| Reportes pueden crecer demasiado | Empezar con reportes operativos esenciales. |

## Guion de demo sugerido

1. Iniciar sesión como administradora.
2. Crear producto con código de barras, precio, stock mínimo y proveedor.
3. Registrar ingreso de stock con vencimiento.
4. Crear oferta temporal.
5. Iniciar sesión como empleado.
6. Escanear producto en nueva venta.
7. Modificar cantidad.
8. Confirmar venta.
9. Ver descuento de stock.
10. Ver ingreso de caja.
11. Cargar lista de precios de proveedor.
12. Revisar diferencias de costo.
13. Aplicar precio sugerido aprobado.
14. Ver etiqueta pendiente.
15. Registrar consumo interno.
16. Cerrar turno o caja.
17. Consultar reporte y auditoría.

## Observación final

> [!success]
> Esta planificación permite defender un sistema completo sin perder foco: primero se construye la base, luego el inventario, después el circuito venta-stock-caja y finalmente reportes, auditoría, calidad y despliegue.
