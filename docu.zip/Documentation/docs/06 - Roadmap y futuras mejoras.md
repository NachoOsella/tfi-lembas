---
title: Roadmap y futuras mejoras
aliases:
  - Evolución del sistema
  - Backlog futuro
  - Roadmap Lembas
tags:
  - tpf
  - roadmap
  - futuro
  - mejoras
  - backlog
cssclasses:
  - wide-page
---

# Roadmap y futuras mejoras

> [!abstract]
> Esta nota ordena la evolución de Lembas en fases. El objetivo es demostrar que el TPF tiene un alcance inicial realista y, al mismo tiempo, una visión clara de crecimiento técnico y funcional.

## Criterio de evolución

La evolución del sistema debe respetar una regla: primero consolidar el núcleo operativo y luego agregar automatizaciones o integraciones. En una dietética, la prioridad no está en sumar complejidad, sino en asegurar que productos, stock, vencimientos, ventas simples, caja, proveedores, listas de precios y actualización asistida de precios sean confiables.

El roadmap se organiza en fases incrementales:

1. núcleo transaccional;
2. proveedores, listas de precios y actualización asistida;
3. optimización operativa;
4. reportes, reposición y automatización;
5. integraciones externas;
6. evolución arquitectónica.

---

# Fase 1: MVP operativo defendible

## Objetivo

Construir una primera versión estable que permita demostrar el circuito principal del negocio: producto, stock, venta, caja, proveedores, actualización de precios y auditoría.

## Funcionalidades incluidas

- autenticación y roles básicos;
- vista de administradora y vista de empleado;
- gestión de productos con código de barras opcional;
- categorías, marcas, presentaciones y proveedores;
- relación ProductoProveedor;
- carga de listas de precios por Excel;
- carga de texto copiado desde WhatsApp;
- revisión y aplicación asistida de costos/precios;
- etiquetas pendientes;
- stock por lotes y vencimiento;
- movimientos de stock;
- venta mostrador simplificada con scanner;
- búsqueda manual para productos sin código de barras;
- modificación de cantidad en venta;
- modificación controlada de precio en venta;
- descuento automático de stock por FEFO;
- ingreso automático de caja por venta;
- caja con movimientos manuales;
- consumo interno;
- ofertas temporales simples;
- reportes básicos;
- auditoría de acciones críticas.

## Resultado esperado

Una demo de punta a punta en la que se pueda:

1. crear un producto con stock y vencimiento;
2. escanearlo en una venta;
3. aplicar una oferta o modificar cantidad;
4. confirmar la venta;
5. ver descuento de stock;
6. ver ingreso en caja;
7. cargar una lista de proveedor;
8. comparar costo anterior y costo nuevo;
9. aprobar un cambio de precio;
10. ver etiqueta pendiente;
11. consultar auditoría o historial.

---

# Fase 2: proveedores, precios y reposición

## Objetivo

Consolidar la gestión de proveedores, listas de precios, comparación de costos y reposición sugerida.

## Funcionalidades incluidas o candidatas

- carga manual de precios de proveedor;
- importación Excel robusta;
- carga de texto de WhatsApp con revisión de líneas;
- estados de reconocimiento de ítems;
- reglas de margen y redondeo;
- comparación entre proveedores;
- etiquetas pendientes por cambios de precio;
- reposición sugerida por stock mínimo e ideal;
- pedidos a proveedores en estado borrador;
- recepción de mercadería con lotes y vencimientos.

> [!important]
> PDF, imágenes, fotos, OCR, audio e inteligencia artificial generativa quedan fuera del alcance inicial y solo podrían evaluarse como investigación futura.

---

# Fase 3: mejoras de operación diaria

## Objetivo

Reducir fricción en el uso real del local y mejorar la velocidad de tareas repetitivas.

## Posibles mejoras

- atajos de teclado para venta mostrador;
- foco automático inteligente en campo de scanner;
- favoritos o productos frecuentes;
- búsqueda predictiva de productos;
- panel de tareas del empleado;
- filtros guardados en listados;
- edición masiva controlada de precios;
- impresión de etiquetas por lote de cambios;
- alertas visuales por vencimiento en venta;
- cierre de turno guiado;
- historial visual de movimientos de stock.

## Valor para el negocio

Estas mejoras no cambian el núcleo del sistema, pero hacen que su uso sea más rápido y cómodo durante la atención al público.

---

# Fase 4: reportes avanzados y automatización

## Objetivo

Transformar los datos registrados en información útil para decisiones de reposición, precios y control.

## Posibles mejoras

- reposición sugerida según stock mínimo e ideal;
- rotación por producto y categoría;
- productos más vendidos por período;
- productos con baja rotación;
- productos próximos a vencer con sugerencia de oferta;
- reporte de diferencias de caja;
- reporte de consumo interno por usuario;
- reporte de mermas por motivo;
- dashboard de tendencias;
- comparación entre ventas, stock y reposición;
- comparación histórica de costos por proveedor;
- reportes de listas importadas;
- reportes de etiquetas pendientes;
- reportes de pedidos y recepciones.

## Automatizaciones posibles

- crear alerta automática cuando un producto cae por debajo del stock mínimo;
- sugerir oferta si un lote vence en pocos días;
- marcar productos para reetiquetado después de cambio de precio;
- avisar cierre de caja pendiente;
- generar lista de reposición preliminar.

---

# Fase 5: integraciones externas

## Objetivo

Conectar el sistema con herramientas externas sin comprometer el núcleo transaccional.

## Integraciones posibles

- envío de alertas por email;
- notificaciones por WhatsApp o mensajería externa;
- almacenamiento cloud para backups o exportaciones;
- integración con impresoras de etiquetas;
- integración con lectores más específicos;
- integración avanzada con listas de proveedores;
- webhooks para eventos relevantes.

Quedan como investigación futura, no como compromiso del TPF:

- lectura automática desde PDF;
- lectura automática desde imágenes;
- OCR;
- lectura de catálogos web;
- inteligencia artificial generativa para normalizar listas.

## Criterio técnico

Las integraciones deben implementarse mediante adaptadores desacoplados. Si una integración externa falla, el sistema principal debe seguir funcionando.

---

# Fase 6: funcionalidades comerciales futuras

## Objetivo

Evaluar ampliaciones comerciales una vez consolidada la gestión interna.

## Funcionalidades posibles

- cuentas corrientes de clientes;
- pedidos a proveedores completos si no entran en el MVP;
- recepción avanzada de mercadería contra pedido;
- gestión más completa de compras;
- presupuestos o reservas internas;
- promociones combinadas;
- fidelización básica;
- portal simple de consulta de productos;
- e-commerce acotado.

> [!warning]
> Estas funcionalidades no forman parte del TPF inicial. Se documentan como evolución posible para demostrar criterio de planificación.

---

# Fase 7: evolución arquitectónica

## Objetivo

Separar componentes solo si el volumen, la complejidad o el equipo de desarrollo lo justifican.

## Candidatos a extracción

| Componente | Motivo para extraer |
|---|---|
| Notificaciones | Puede funcionar de forma asincrónica y desacoplada. |
| Reportes pesados | Puede requerir consultas intensivas o generación programada. |
| Exportaciones masivas | Puede ejecutarse como tarea en background. |
| Integraciones externas | Permite aislar fallos de terceros. |
| Auditoría avanzada | Puede crecer como módulo transversal especializado. |

## Criterio de decisión

No se recomienda migrar a microservicios sin necesidad concreta. Para el TPF, el monolito modular es más claro, más mantenible y más fácil de defender.

---

# Backlog futuro priorizado

| Prioridad | Mejora | Valor | Complejidad |
|---|---|---|---|
| Alta | Listas de precios por Excel | Alto | Media |
| Alta | Carga de texto de WhatsApp | Alto | Media |
| Alta | Actualización asistida de precios | Alto | Media |
| Alta | Reposición sugerida | Alto | Media |
| Alta | Etiquetas por productos modificados | Alto | Baja-media |
| Alta | Panel de vencimientos accionable | Alto | Media |
| Media | Notificaciones por email | Medio | Media |
| Media | Pedido a proveedor | Alto | Media-alta |
| Media | Recepción contra pedido | Alto | Media-alta |
| Media | Comparación de costos por proveedor | Alto | Media |
| Media | Reportes de rotación | Medio | Media |
| Baja | WhatsApp externo | Medio | Alta |
| Baja | E-commerce | Alto | Alta |
| Baja | Microservicio de reportes | Variable | Alta |

## Métricas de evolución

Para decidir próximas mejoras, se podrían observar:

- cantidad de ventas registradas por día;
- productos con faltantes frecuentes;
- cantidad de ajustes manuales de stock;
- diferencias de caja recurrentes;
- cantidad de productos vencidos o próximos a vencer;
- tiempo promedio de carga de una venta;
- frecuencia de cambios de precio;
- cantidad de listas de precios cargadas;
- cantidad de ítems no reconocidos por lista;
- diferencias porcentuales de costos por proveedor;
- cantidad de etiquetas pendientes;
- uso real de reportes y exportaciones.

## Mensaje para la defensa

El proyecto debe presentarse como una solución que resuelve hoy un problema operativo concreto y deja bases para crecer. La evolución propuesta demuestra que se tomaron decisiones de alcance: no se intenta implementar todo, sino priorizar lo que aporta trazabilidad, consistencia y valor inmediato para la dietética.
