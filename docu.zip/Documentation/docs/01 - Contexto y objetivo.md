---
title: Contexto y objetivo
aliases:
  - Contexto del sistema Lembas
  - Objetivo del TPF
  - Problema de negocio de Dietética Lembas
tags:
  - tpf
  - analisis
  - negocio
  - objetivos
  - dietetica
  - venta-simplificada
  - stock
cssclasses:
  - wide-page
---

# Contexto y objetivo

> [!abstract]
> Esta nota describe el contexto de negocio de la dietética Lembas, el problema operativo que se busca resolver y los objetivos del Trabajo Práctico Final. La referencia funcional principal es [[00 - TPF Dietética Lembas]], donde se define el sistema como una plataforma web interna con stock por lote y vencimiento, caja, venta mostrador simplificada, código de barras, proveedores múltiples, listas de precios, actualización asistida de precios, ofertas, consumo interno, reposición sugerida y auditoría.

## Contexto del negocio

Lembas es una dietética de una sola sucursal que necesita administrar productos, precios, stock, vencimientos, movimientos de caja y tareas cotidianas del local. Como ocurre en muchos comercios pequeños, parte de la operatoria puede apoyarse en planillas Excel, registros manuales, anotaciones informales y control visual de la mercadería.

Este esquema puede funcionar en etapas iniciales, pero se vuelve limitado cuando el negocio requiere trazabilidad, consistencia y velocidad operativa. La dietética trabaja con productos variados, muchos de ellos con vencimiento, distintas presentaciones, precios que pueden cambiar, promociones temporales, productos sin código de barras y consumos internos que deben diferenciarse de ventas, mermas o ajustes.

Además, la relación con proveedores agrega una dificultad específica: distintos proveedores pueden enviar listas de precios en formatos diferentes, con nombres de productos no normalizados y costos que cambian periódicamente. Por eso, el sistema debe contemplar la carga de listas por Excel, texto copiado desde WhatsApp o carga manual, permitiendo comparar costos nuevos contra costos anteriores antes de modificar precios de venta.

La incorporación de un lector de código de barras permite plantear una mejora relevante: registrar ventas simples de mostrador sin convertir el proyecto en un punto de venta fiscal completo. Esa decisión conecta tres procesos críticos: venta, caja y stock.

## Situación actual

La operatoria actual o esperada sin sistema centralizado presenta riesgos como:

- datos dispersos entre planillas, notas y memoria operativa;
- carga manual repetida de productos, precios y cantidades;
- dificultad para saber el stock real disponible;
- falta de separación clara entre stock total y stock por vencimiento;
- poca visibilidad sobre productos próximos a vencer;
- errores por precios desactualizados en etiquetas o listados;
- dificultad para comparar listas de precios de distintos proveedores;
- falta de mapeo entre productos internos y nombres usados por cada proveedor;
- ausencia de reglas claras de margen y redondeo para sugerir precios;
- dificultad para registrar ventas simples y descontar stock automáticamente;
- movimientos de caja no vinculados a operaciones concretas;
- consumo interno de empleados o dueña sin registro formal;
- mermas, roturas y vencimientos mezclados con ajustes genéricos;
- ausencia de historial confiable para auditar quién hizo cada cambio;
- reportes manuales lentos o inconsistentes.

## Problema a resolver

El problema central es la **falta de una plataforma unificada de gestión interna** que permita registrar la operación diaria de forma consistente, trazable y accesible desde dispositivos del local.

En términos de negocio, la ausencia de un sistema integrado dificulta responder preguntas básicas:

- ¿Qué stock real hay disponible de cada producto?
- ¿Qué lote vence primero y debe venderse o retirarse antes?
- ¿Qué productos requieren reposición?
- ¿Qué proveedor conviene para reponer cada producto?
- ¿Qué costos cambiaron respecto de la última lista?
- ¿Qué etiquetas quedaron pendientes después de actualizar precios?
- ¿Qué ventas se realizaron durante el turno?
- ¿Qué ingreso de caja corresponde a una venta confirmada?
- ¿Qué productos fueron consumidos internamente y por quién?
- ¿Qué ofertas estuvieron vigentes y qué precio se aplicó en cada venta?
- ¿Qué usuario modificó un precio, un stock o un cierre de caja?

## Objetivo general

Diseñar e implementar una **aplicación web interna para la dietética Lembas** que centralice la gestión de productos, stock por lote y vencimiento, proveedores, listas de precios, actualización asistida de precios, venta mostrador simplificada, caja, consumo interno, ofertas temporales, etiquetas, importación/exportación, reportes y auditoría, utilizando una arquitectura web moderna basada en Angular, Spring Boot y PostgreSQL.

## Objetivos específicos

1. Centralizar la información operativa en una base de datos PostgreSQL.
2. Administrar usuarios internos con roles diferenciados para administradora/dueña y empleados.
3. Gestionar productos, categorías, marcas, proveedores, precios y códigos de barras.
4. Registrar stock por lotes o partidas con fecha de vencimiento cuando corresponda.
5. Descontar stock mediante criterio FEFO en ventas, consumos internos, mermas o vencimientos.
6. Registrar ventas mostrador simplificadas usando lector de código de barras o búsqueda manual.
7. Guardar en cada venta el precio histórico aplicado, incluyendo ofertas o modificaciones manuales.
8. Permitir modificación controlada de cantidad y precio durante una venta antes de confirmarla.
9. Registrar automáticamente ingresos de caja asociados a ventas confirmadas.
10. Permitir movimientos manuales de caja, cierre de turno y cierre diario con diferencias.
11. Diferenciar venta, consumo interno, merma, vencimiento y ajuste de stock.
12. Gestionar ofertas temporales por producto y rango de fechas.
13. Generar etiquetas o listados de precios imprimibles.
14. Importar y exportar información mediante archivos Excel.
15. Permitir carga de listas de precios copiadas desde WhatsApp o cargadas manualmente.
16. Mapear productos internos con productos o nombres usados por proveedores.
17. Comparar costos nuevos contra costos anteriores antes de aplicar cambios.
18. Sugerir precios de venta mediante reglas de margen y redondeo, con aprobación de la dueña.
19. Marcar etiquetas pendientes cuando cambie el precio de venta o se cree una oferta.
20. Soportar reposición sugerida a partir de stock mínimo, stock ideal y proveedor.
21. Contemplar pedidos a proveedores y recepción de mercadería como alcance intermedio o evolución inmediata.
22. Producir reportes operativos sobre stock, vencimientos, ventas, caja, consumo interno, mermas, cambios de precio, listas importadas y etiquetas pendientes.
23. Auditar acciones críticas para mejorar la trazabilidad del sistema.
24. Priorizar una interfaz mobile-first para uso ágil en mostrador, depósito o administración.

## Alcance de negocio

> [!note]
> El sistema se define como una herramienta de **gestión interna**. Incluye una venta mostrador simplificada con impacto en stock y caja, pero no reemplaza un sistema fiscal ni un POS comercial completo.

### Incluye

- autenticación, roles y permisos;
- gestión de productos, categorías, marcas, presentaciones y proveedores;
- relación entre productos internos y productos de proveedor;
- carga de listas de precios por Excel, texto de WhatsApp o carga manual;
- comparación de costos y actualización asistida de precios;
- reglas de margen y redondeo;
- código de barras opcional por producto;
- stock por lotes y vencimientos;
- movimientos de stock trazables;
- venta mostrador simplificada con scanner;
- búsqueda manual para productos sin código de barras;
- modificación controlada de cantidad y precio en venta;
- ofertas temporales;
- consumo interno de empleados o dueña;
- mermas y retiros por vencimiento;
- caja interna, ingresos, egresos y cierres;
- actualización de precios e impresión de etiquetas;
- etiquetas pendientes ante cambios de precio u ofertas;
- importación/exportación Excel;
- reportes, métricas y alertas;
- auditoría de acciones relevantes.

### No incluye en esta etapa

- facturación fiscal;
- integración con AFIP;
- emisión de comprobantes legales;
- pasarela de pagos;
- e-commerce;
- portal de clientes;
- cuentas corrientes o fidelización;
- multi-sucursal;
- integración obligatoria con medios de pago externos;
- contabilidad avanzada;
- lectura automática desde PDF;
- lectura automática desde imágenes o fotos;
- OCR;
- inteligencia artificial generativa;
- data warehouse o analítica predictiva avanzada.

## Valor para el negocio

| Beneficio | Impacto esperado |
|---|---|
| Centralización | Reduce dependencia de planillas y registros informales. |
| Stock confiable | Permite conocer disponibilidad real y lotes próximos a vencer. |
| Venta operativa | Registra ventas simples, suma caja y descuenta stock automáticamente. |
| Caja ordenada | Relaciona ingresos por venta y movimientos manuales con responsables. |
| Trazabilidad | Permite saber quién realizó cambios sensibles y cuándo. |
| Control de precios | Conserva historial de precios, precio aplicado en cada venta y cambios aprobados desde listas de proveedor. |
| Proveedores | Permite comparar costos, detectar cambios y elegir mejor abastecimiento. |
| Etiquetas pendientes | Reduce el riesgo de precios exhibidos desactualizados. |
| Consumo interno claro | Evita confundir consumo de empleados con ventas, mermas o faltantes. |
| Alertas | Anticipa vencimientos, bajo stock y cierres pendientes. |
| Reportes | Mejora la toma de decisiones con información persistida y exportable. |
| Usabilidad | Facilita operación desde celular, tablet o computadora del local. |

## Principios de diseño

El sistema debe sostenerse sobre cinco principios:

1. **simplicidad operativa**, para que pueda usarse durante la atención diaria;
2. **consistencia transaccional**, para que venta, stock y caja no queden desalineados;
3. **trazabilidad**, para registrar responsables y motivos de acciones críticas;
4. **separación por roles**, para proteger información sensible del negocio;
5. **evolutividad técnica**, para permitir nuevas integraciones sin rehacer el núcleo.

## Criterio de éxito académico

El TPF será exitoso si demuestra que el sistema resuelve un problema real mediante:

- análisis profundo del dominio de una dietética;
- alcance funcional realista pero suficientemente completo;
- arquitectura coherente y defendible;
- modelo de datos capaz de representar operaciones críticas;
- reglas de negocio claras;
- interfaz orientada a los usuarios internos;
- trazabilidad y auditoría;
- posibilidad de despliegue en nube;
- documentación consistente entre módulos, casos de uso, requisitos y sprints.
