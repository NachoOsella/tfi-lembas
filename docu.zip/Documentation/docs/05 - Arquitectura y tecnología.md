---
title: Arquitectura y tecnología
aliases:
  - Arquitectura del sistema
  - Stack tecnológico
  - Arquitectura Lembas
tags:
  - tpf
  - arquitectura
  - spring-boot
  - angular
  - postgresql
  - monolito-modular
cssclasses:
  - wide-page
---

# Arquitectura y tecnología

> [!abstract]
> Propuesta técnica para Lembas: aplicación web mobile-first con frontend Angular, backend Spring Boot, base de datos PostgreSQL y arquitectura de monolito modularizado. La arquitectura está pensada para sostener procesos integrados de venta mostrador simplificada, stock por vencimiento, caja, ofertas, consumo interno, proveedores, listas de precios, actualización asistida, pedidos, recepción y auditoría.

## Objetivo arquitectónico

La arquitectura debe permitir implementar un sistema interno robusto, trazable y defendible académicamente, sin sobredimensionar la solución. El objetivo no es distribuir el sistema en múltiples servicios desde el inicio, sino lograr una separación clara por módulos dentro de un monolito mantenible.

La decisión de monolito modularizado es adecuada porque:

- el dominio pertenece a una sola sucursal;
- las operaciones críticas requieren transacciones entre módulos;
- venta, stock y caja deben mantenerse consistentes;
- el alcance del TPF necesita claridad y velocidad de desarrollo;
- permite evolucionar a servicios separados solo si el crecimiento lo justifica.

## Stack propuesto

| Capa | Tecnología | Motivo |
|---|---|---|
| Frontend | Angular | Framework robusto para SPA, componentes reutilizables y experiencia mobile-first. |
| Backend | Spring Boot | Ecosistema maduro, integración con seguridad, JPA, validaciones y API REST. |
| Base de datos | PostgreSQL | Consistencia transaccional, integridad referencial y consultas de reportes. |
| Persistencia | Spring Data JPA / Hibernate | Productividad y mapeo relacional adecuado para entidades del dominio. |
| Seguridad | Spring Security + JWT | Autenticación, autorización por roles y protección de endpoints. |
| Migraciones | Flyway o Liquibase | Versionado del esquema de base de datos. |
| API docs | OpenAPI / Swagger | Documentación de endpoints y soporte para pruebas. |
| Importación Excel | Apache POI u opción equivalente | Lectura y generación de archivos de planilla. |
| Carga texto WhatsApp | Parser propio acotado | Interpretación supervisada de líneas copiadas desde mensajes. |
| Validaciones | Bean Validation | Validación declarativa de DTOs y entidades. |
| Reportes/impresión | PDF/HTML imprimible | Etiquetas, listados y reportes exportables. |
| Reverse proxy | Nginx | HTTPS, ruteo `/api`, headers, compresión y publicación ordenada. |
| Contenedores | Docker / Docker Compose | Reproducibilidad local y base para despliegue. |
| Despliegue | Nube | Acceso desde dispositivos del local y presentación del TPF. |

## Estilo arquitectónico

Se propone una arquitectura por capas dentro de un monolito modular:

```text
Frontend Angular
        ↓
API REST Spring Boot
        ↓
Servicios de aplicación
        ↓
Dominio y reglas de negocio
        ↓
Repositorios e infraestructura
        ↓
PostgreSQL
```

### Capas del backend

| Capa | Responsabilidad |
|---|---|
| Presentación | Controllers REST, DTOs, validación de entrada y salida HTTP. |
| Aplicación | Casos de uso, coordinación de transacciones y orquestación entre módulos. |
| Dominio | Entidades, reglas, invariantes y decisiones del negocio. |
| Infraestructura | Repositorios, integraciones, Excel, PDF, email futuro, persistencia y adaptadores. |

## Módulos principales

| Módulo | Responsabilidad |
|---|---|
| Usuarios y seguridad | Autenticación, roles, permisos y sesión. |
| Productos | Catálogo, categorías, marcas, códigos de barras y precios base. |
| Proveedores | Datos comerciales, relación producto-proveedor y costos por proveedor. |
| Listas de precios | Carga Excel/WhatsApp/manual, normalización, reconocimiento y revisión. |
| Pricing | Reglas de margen, redondeo, sugerencias y aplicación aprobada de precios. |
| Compras | Reposición sugerida, pedidos a proveedores y recepción de mercadería. |
| Stock | Lotes, vencimientos, movimientos, FEFO, inventario y alertas. |
| Ventas | Venta mostrador simplificada, detalles, confirmación y anulación. |
| Ofertas | Promociones temporales y reglas de aplicación. |
| Consumo interno | Registro de consumo de empleados o dueña sin impacto en caja. |
| Caja | Movimientos automáticos/manuales, turnos y cierres. |
| Etiquetas y precios | Historial de precios, etiquetas y listados imprimibles. |
| Reportes | Consultas agregadas, métricas y exportaciones. |
| Importación/exportación | Excel, validación, errores y auditoría de cargas masivas. |
| Auditoría | Registro transversal de acciones críticas. |
| Alertas | Stock bajo, vencimientos, cierres pendientes y tareas operativas. |

## Diagrama de módulos

```mermaid
graph TD
    A[Angular Web App] --> B[Spring Boot API]
    B --> C[Seguridad]
    B --> D[Productos]
    B --> E[Proveedores]
    B --> F[Stock]
    B --> G[Ventas]
    B --> H[Ofertas]
    B --> I[Consumo Interno]
    B --> J[Caja]
    B --> K[Reportes]
    B --> L[Listas de precios]
    B --> O[Pricing]
    B --> P[Pedidos y recepción]
    B --> Q[Etiquetas]
    B --> M[Auditoría]
    B --> N[Alertas]
    C --> DB[(PostgreSQL)]
    D --> DB
    E --> DB
    F --> DB
    G --> DB
    H --> DB
    I --> DB
    J --> DB
    K --> DB
    L --> DB
    O --> DB
    P --> DB
    Q --> DB
    M --> DB
    N --> DB
```

## Flujos transaccionales críticos

### Confirmación de venta

```mermaid
sequenceDiagram
    actor U as Usuario
    participant F as Frontend Angular
    participant V as VentasService
    participant S as StockService
    participant C as CajaService
    participant A as AuditoriaService
    participant DB as PostgreSQL

    U->>F: Confirma venta
    F->>V: POST /ventas/{id}/confirmar
    V->>S: Validar y descontar stock FEFO
    S->>DB: Registrar movimientos de stock
    V->>C: Registrar ingreso de caja
    C->>DB: Guardar movimiento de caja
    V->>DB: Marcar venta confirmada
    V->>A: Auditar confirmación
    A->>DB: Guardar auditoría
    V-->>F: Venta confirmada
```

### Consumo interno

```mermaid
sequenceDiagram
    actor U as Usuario
    participant CI as ConsumoInternoService
    participant S as StockService
    participant A as AuditoriaService
    participant DB as PostgreSQL

    U->>CI: Registra consumo interno
    CI->>CI: Validar razón y permisos
    CI->>S: Descontar stock FEFO
    S->>DB: Movimiento CONSUMO_INTERNO
    CI->>DB: Guardar consumo
    CI->>A: Auditar operación
```

### Aplicación de lista de precios

```mermaid
sequenceDiagram
    actor A as Administradora
    participant PL as PriceListService
    participant PR as PricingService
    participant L as LabelService
    participant AU as AuditoriaService
    participant DB as PostgreSQL

    A->>PL: Aplica lista revisada
    PL->>PL: Validar estado EN_REVISION
    PL->>DB: Actualizar costo proveedor
    PL->>DB: Guardar historial de costo
    PL->>PR: Calcular/aplicar precios aprobados
    PR->>DB: Guardar historial de precio
    PR->>L: Marcar etiquetas pendientes
    L->>DB: Actualizar productos
    PL->>AU: Auditar aplicación
```

### Recepción de mercadería

```mermaid
sequenceDiagram
    actor A as Administradora
    participant P as PurchasesService
    participant S as StockService
    participant AU as AuditoriaService
    participant DB as PostgreSQL

    A->>P: Confirma recepción
    P->>P: Validar pedido o carga manual
    P->>S: Crear lotes y movimientos de ingreso
    S->>DB: Registrar INGRESO_COMPRA
    P->>DB: Actualizar estado del pedido
    P->>AU: Auditar recepción
```

## Modelo de despliegue

```mermaid
flowchart LR
    U[Usuario interno] --> N[Nginx Reverse Proxy]
    N --> A[Angular SPA]
    N --> B[Spring Boot API]
    B --> DB[(PostgreSQL)]
    B --> X[Generación Excel/PDF]
```

### Rol de Nginx

Nginx se utiliza como componente de borde para:

- servir la SPA Angular o enrutar hacia ella;
- redirigir `/api` hacia Spring Boot;
- terminar TLS/HTTPS;
- aplicar compresión;
- configurar headers de seguridad;
- evitar exponer directamente el puerto interno del backend.

> [!important]
> Nginx no vuelve invisible la API, ya que el navegador debe consumir endpoints. Su valor es ordenar el despliegue, centralizar la entrada y reducir exposición innecesaria.

## Seguridad

Medidas principales:

- autenticación mediante JWT o sesión segura;
- autorización por rol y permiso en backend;
- guardas de rutas en Angular;
- validación server-side de todas las operaciones;
- hash seguro de contraseñas;
- baja lógica en entidades críticas;
- auditoría de acciones sensibles;
- protección de endpoints administrativos;
- manejo centralizado de errores;
- CORS restringido según ambiente;
- headers de seguridad desde Nginx.

## Consistencia y transacciones

Los procesos que cruzan módulos deben ejecutarse de forma transaccional:

| Proceso | Módulos involucrados | Requisito de consistencia |
|---|---|---|
| Confirmar venta | Ventas, Stock, Caja, Auditoría | Todo se confirma o todo se revierte. |
| Anular venta | Ventas, Stock, Caja, Auditoría | Debe generar estado o compensación consistente. |
| Consumo interno | Consumo, Stock, Auditoría | No impacta caja y descuenta stock correctamente. |
| Ajuste de stock | Stock, Auditoría | Debe registrar motivo y responsable. |
| Cierre de caja | Caja, Auditoría | Debe preservar saldo esperado, contado y diferencia. |
| Importación masiva | Productos/Stock/Precios, Auditoría | Debe validar antes de persistir. |
| Aplicar lista de precios | Proveedores, Listas, Pricing, Etiquetas, Auditoría | Requiere revisión, historial y aprobación. |
| Recepción de mercadería | Compras, Stock, Proveedores, Auditoría | Debe crear lotes, movimientos de ingreso y actualizar estado de pedido. |

## Frontend Angular

El frontend debe organizarse por módulos o features:

- autenticación;
- home admin;
- home empleado;
- productos;
- proveedores;
- listas de precios;
- pricing;
- pedidos y recepción;
- stock;
- ventas;
- caja;
- ofertas;
- consumo interno;
- reportes;
- configuración.

Criterios de diseño:

- mobile-first;
- formularios breves;
- botones grandes para uso táctil;
- búsqueda rápida de productos;
- foco automático en campo de scanner durante venta;
- vistas diferenciadas por rol;
- tablas responsivas;
- feedback claro de errores y confirmaciones.

## Backend Spring Boot

Criterios de implementación:

- controllers delgados;
- servicios de aplicación para casos de uso;
- validaciones con Bean Validation y reglas de dominio;
- DTOs para no exponer entidades directamente;
- repositorios por agregado o entidad principal;
- transacciones explícitas en operaciones críticas;
- excepciones de negocio controladas;
- documentación OpenAPI;
- pruebas unitarias e integración en servicios críticos.

## Base de datos PostgreSQL

Criterios de datos:

- claves primarias técnicas;
- claves foráneas para integridad;
- índices en búsquedas frecuentes;
- restricciones únicas para código de barras activo;
- columnas de auditoría;
- estados en entidades transaccionales;
- versionado de esquema con Flyway o Liquibase.

Índices recomendados:

| Tabla | Índice sugerido | Motivo |
|---|---|---|
| producto | codigo_barras | Búsqueda por scanner. |
| producto | nombre | Búsqueda manual. |
| producto_proveedor | producto_id, proveedor_id | Comparación y mapeo por proveedor. |
| lista_precio_proveedor | proveedor_id, fecha_lista | Historial de listas. |
| item_lista_precio_proveedor | lista_id, estado_reconocimiento | Revisión de ítems. |
| historial_costo_proveedor | producto_proveedor_id, fecha_vigencia | Comparación histórica de costos. |
| lote_stock | producto_id, fecha_vencimiento | FEFO y vencimientos. |
| movimiento_stock | producto_id, fecha_hora | Historial de stock. |
| venta | fecha_hora, usuario_id, estado | Consultas por turno o día. |
| movimiento_caja | fecha_hora, tipo | Reportes de caja. |
| auditoria | entidad, entidad_id, fecha_hora | Trazabilidad. |

## Endpoints REST orientativos

Los endpoints deben documentarse con OpenAPI/Swagger. Una organización posible es:

```text
GET    /api/v1/products
GET    /api/v1/products/barcode/{barcode}
POST   /api/v1/products
PUT    /api/v1/products/{id}
PATCH  /api/v1/products/{id}/deactivate

GET    /api/v1/suppliers
POST   /api/v1/suppliers
PUT    /api/v1/suppliers/{id}
GET    /api/v1/suppliers/{id}/products
POST   /api/v1/suppliers/{id}/products

POST   /api/v1/suppliers/{supplierId}/price-lists/excel
POST   /api/v1/suppliers/{supplierId}/price-lists/text
POST   /api/v1/suppliers/{supplierId}/price-lists/manual
GET    /api/v1/price-lists/{id}/items
PATCH  /api/v1/price-lists/{id}/items/{itemId}/resolve
POST   /api/v1/price-lists/{id}/apply
POST   /api/v1/price-lists/{id}/discard

GET    /api/v1/pricing/suggestions
POST   /api/v1/pricing/apply
GET    /api/v1/products/{id}/price-history

POST   /api/v1/sales
POST   /api/v1/sales/{id}/confirm
POST   /api/v1/sales/{id}/cancel

POST   /api/v1/purchase-orders
POST   /api/v1/purchase-orders/{id}/send
POST   /api/v1/purchase-orders/{id}/receive
```

## Evolución futura

Si el sistema crece, podrían extraerse componentes específicos:

- notificaciones externas;
- reportes pesados;
- integraciones externas con proveedores;
- exportaciones masivas;
- lectura avanzada de documentos si alguna vez se decide incorporar PDF/OCR fuera del MVP;
- mensajería externa.

No se recomienda iniciar con microservicios porque aumentaría la complejidad sin una necesidad real para el TPF.

## Justificación final

La arquitectura propuesta equilibra:

1. claridad académica;
2. desarrollo realista;
3. consistencia de datos;
4. trazabilidad;
5. seguridad por roles;
6. experiencia mobile-first;
7. capacidad de despliegue;
8. evolución técnica futura.
