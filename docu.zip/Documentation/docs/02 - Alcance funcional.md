---
title: Alcance funcional
aliases:
  - Scope funcional
  - Módulos del sistema
  - Alcance de Lembas
tags:
  - tpf
  - alcance
  - funcional
  - modulos
  - venta-simplificada
  - caja
  - stock
cssclasses:
  - wide-page
---

# Alcance funcional

> [!abstract]
> Esta nota define el alcance funcional de Lembas para una primera versión defendible del TPF. Se actualiza según [[00 - TPF Dietética Lembas]] e incorpora venta mostrador simplificada, scanner, stock FEFO, caja, ofertas temporales, consumo interno, proveedores múltiples, listas de precios, actualización asistida de precios, pedidos/recepción, roles y auditoría.

## Criterio general de alcance

Lembas será una **plataforma web de gestión interna** para una dietética de una sola sucursal. El sistema se enfoca en resolver operaciones reales del local: administrar productos, controlar stock y vencimientos, registrar ventas simples de mostrador, descontar stock, actualizar caja, gestionar proveedores y listas de precios, comparar costos, sugerir precios de venta, diferenciar consumos internos y generar información trazable.

La primera versión no busca ser un POS fiscal completo. La venta se incluye con alcance acotado porque aporta valor operativo y permite integrar los módulos de stock y caja.

---

# Alcance incluido

## 1. Gestión de usuarios, roles y permisos

Incluye:

- alta, edición, consulta y baja lógica de usuarios;
- autenticación con credenciales;
- roles base: administradora/dueña y empleado;
- permisos por funcionalidad;
- restricción de vistas según rol;
- registro de acciones sensibles por usuario;
- activación e inactivación de cuentas.

Diferenciación principal:

| Rol | Alcance |
|---|---|
| Administradora/Dueña | Acceso completo a gestión, reportes, caja, configuración, usuarios y auditoría. |
| Empleado | Acceso operativo a venta, consulta de productos, stock visible, tareas de turno y acciones permitidas. |

## 2. Gestión de productos

Incluye:

- alta, edición, consulta y baja lógica de productos;
- nombre, descripción, categoría, marca y presentación;
- código de barras opcional;
- precio de venta base;
- costo estimado o costo de referencia;
- stock mínimo e ideal;
- proveedor habitual;
- estado activo/inactivo;
- observaciones;
- búsqueda por nombre, categoría, marca, presentación o código de barras;
- historial de cambios relevantes de precio o estado.

El código de barras será opcional porque algunos productos de dietética pueden venderse sueltos, fraccionados o sin envase codificado.

## 3. Gestión de categorías, marcas, presentaciones y proveedores

Incluye:

- administración de categorías, marcas y presentaciones;
- alta, edición y baja lógica de proveedores;
- datos de contacto y comerciales;
- registro de método habitual de envío de lista de precios;
- relación entre productos internos y productos de proveedores;
- proveedor habitual y proveedores alternativos;
- nombre, código y presentación del producto según cada proveedor;
- consulta de productos asociados a cada proveedor;
- comparación de costos entre proveedores;
- soporte para reposición sugerida.

## 4. Stock por lotes y vencimiento

Incluye:

- registro de stock por producto;
- separación por lote, partida o fecha de vencimiento cuando aplique;
- consulta de stock total y detalle por vencimiento;
- ingresos de mercadería;
- ajustes positivos y negativos;
- mermas, roturas y vencimientos;
- consumo interno;
- descuento automático por venta;
- criterio FEFO para productos con vencimiento;
- alertas de stock bajo y vencimiento próximo;
- trazabilidad de cada movimiento.

## 5. Movimientos de stock

Todo cambio de stock debe generar un movimiento auditable.

Tipos mínimos incluidos:

| Tipo | Descripción | Impacta caja |
|---|---|---|
| `INGRESO_COMPRA` | Entrada por compra o recepción. | No directamente |
| `EGRESO_VENTA` | Salida por venta confirmada. | Sí |
| `CONSUMO_INTERNO` | Producto consumido internamente. | No |
| `MERMA` | Pérdida, rotura o deterioro. | No |
| `VENCIMIENTO` | Retiro por vencimiento. | No |
| `AJUSTE_POSITIVO` | Corrección que suma stock. | No |
| `AJUSTE_NEGATIVO` | Corrección que resta stock. | No |
| `DEVOLUCION` | Corrección o devolución asociada. | Depende del caso |

## 6. Venta mostrador simplificada

Incluye:

- creación de venta en estado borrador;
- lectura de código de barras mediante scanner configurado como entrada de teclado;
- búsqueda de producto por código de barras;
- búsqueda manual por nombre, categoría, marca o presentación;
- agregado de productos al detalle;
- modificación de cantidad antes de confirmar;
- modificación controlada de precio con permiso y motivo;
- aplicación de ofertas temporales activas;
- cálculo de subtotal y total;
- confirmación de venta;
- descuento automático de stock por FEFO;
- generación automática de movimiento de caja por ingreso;
- anulación controlada mediante estado o movimiento compensatorio;
- consulta de ventas por turno o fecha.

No incluye facturación fiscal ni emisión de comprobantes legales.

## 7. Ofertas temporales

Incluye:

- creación y edición de ofertas por producto;
- tipo de oferta por porcentaje o precio fijo;
- fecha de inicio y fin;
- estado activo/inactivo;
- aplicación automática o sugerida en venta;
- registro del precio final aplicado en el detalle de venta;
- auditoría de creación, modificación y desactivación.

La venta debe guardar el precio aplicado para que una modificación posterior de la oferta no altere ventas históricas.

## 8. Consumo interno

Incluye:

- registro de productos consumidos por empleados o dueña;
- selección de producto y cantidad;
- razón de consumo;
- descuento de stock por FEFO;
- ausencia de ingreso en caja;
- posible aprobación por administradora según configuración;
- consulta y reporte de consumos internos;
- auditoría del usuario responsable.

Ejemplos de razón:

- consumo de empleado;
- consumo de dueña;
- degustación;
- muestra;
- capacitación;
- otro con descripción obligatoria.

## 9. Caja interna y cierres

Incluye:

- apertura de caja o turno;
- ingresos automáticos por ventas confirmadas;
- ingresos manuales;
- egresos manuales;
- retiros y gastos operativos;
- consulta de movimientos;
- cierre de turno;
- cierre diario;
- saldo inicial, saldo esperado, saldo contado y diferencia;
- observaciones y responsable;
- restricción de modificaciones sobre cierres confirmados.

## 10. Proveedores, listas de precios y actualización asistida

Incluye:

- importación de listas de precios por Excel;
- carga de listas copiadas desde WhatsApp;
- carga manual de precios de proveedor;
- normalización de líneas o ítems de lista;
- reconocimiento de productos internos a partir de productos de proveedor;
- estados de reconocimiento: reconocido, posible coincidencia, no reconocido, nuevo producto e ignorado;
- comparación entre costo anterior y costo nuevo;
- aprobación manual antes de aplicar cambios;
- historial de costo por proveedor;
- reglas de margen y redondeo por categoría o producto;
- cálculo de precio de venta sugerido;
- aplicación selectiva o por lote de precios aprobados;
- generación de etiquetas pendientes si cambia el precio de venta.

> [!important]
> La actualización automática ciega queda fuera del enfoque. El sistema sugiere y asiste, pero la dueña aprueba qué cambios aplicar.

## 11. Pedidos a proveedores y recepción de mercadería

Incluye como alcance intermedio o extensión directa del MVP:

- reposición sugerida según stock mínimo e ideal;
- agrupación de sugerencias por proveedor;
- creación de pedido proveedor en estado borrador;
- estados de pedido: borrador, enviado, recibido parcial, recibido y cancelado;
- recepción manual o contra pedido;
- registro de cantidades recibidas;
- carga de lotes y vencimientos durante la recepción;
- generación de movimientos `INGRESO_COMPRA`;
- actualización de costo proveedor si corresponde;
- auditoría de recepción.

## 12. Precios, etiquetas e impresión

Incluye:

- actualización individual de precios;
- historial básico de cambios de precio;
- marcado de `etiquetaPendiente` ante cambios de precio u ofertas;
- generación de etiquetas imprimibles;
- generación de listados de precios;
- filtros por productos modificados, categoría, proveedor u ofertas;
- exportación a PDF/HTML imprimible según implementación.

## 13. Importación y exportación

Incluye:

- importación controlada de productos, stock, precios o listas de proveedor;
- carga estructurada desde Excel;
- carga semiestructurada desde texto copiado de WhatsApp;
- carga manual de precios;
- validación previa de estructura;
- vista previa de errores;
- registro de incidencias de importación;
- confirmación antes de persistir;
- exportación de productos, stock, proveedores, ventas, caja y reportes.

## 14. Reportes, métricas y alertas

Incluye reportes de:

- stock actual;
- stock bajo;
- próximos vencimientos;
- movimientos de stock;
- ventas por día o turno;
- productos vendidos;
- caja y cierres;
- consumo interno;
- mermas;
- ofertas vigentes;
- proveedores y productos asociados;
- listas de precios importadas;
- cambios de costo;
- comparación de costos por proveedor;
- etiquetas pendientes;
- pedidos y recepciones si se implementan.

Incluye alertas de:

- stock crítico;
- vencimiento próximo;
- cierre de caja pendiente;
- importación con errores;
- productos que requieren reposición.

## 15. Auditoría

Incluye auditoría de:

- inicio de sesión relevante o cambios de seguridad;
- alta, edición o baja de productos;
- cambios de precio;
- ajustes de stock;
- ventas confirmadas o anuladas;
- modificación manual de precio en venta;
- creación o modificación de ofertas;
- consumos internos;
- movimientos y cierres de caja;
- importaciones masivas;
- aprobación de cambios de costo/precio;
- recepción de mercadería;
- generación o cambio de estado de pedidos a proveedor.

---

# Alcance excluido

> [!warning]
> Estos elementos quedan fuera del TPF para mantener un alcance realista y evitar convertir el sistema en una solución fiscal, contable o comercial completa.

- facturación fiscal;
- integración con AFIP;
- comprobantes legales;
- punto de venta completo;
- integración real con pasarelas de pago;
- control de tarjetas, QR o acreditaciones bancarias;
- portal de clientes;
- e-commerce;
- multi-sucursal;
- cuentas corrientes;
- fidelización avanzada;
- contabilidad general;
- libro IVA o reportes fiscales;
- sincronización offline;
- integración obligatoria con balanzas;
- impresoras fiscales;
- lectura automática de PDF;
- lectura automática de imágenes o fotos;
- OCR;
- audio de WhatsApp;
- lectura automática desde catálogos web;
- inteligencia artificial generativa;
- data warehouse o BI avanzado.

---

# MVP recomendado

Para una primera versión funcional, demostrable y defendible, se recomienda implementar:

1. autenticación y roles básicos;
2. productos con código de barras opcional;
3. categorías, marcas y proveedores;
4. stock por lotes y vencimiento;
5. movimientos de stock;
6. venta mostrador con scanner y búsqueda manual;
7. modificación de cantidad en venta;
8. modificación controlada de precio en venta;
9. ofertas temporales simples;
10. descuento automático de stock por FEFO;
11. consumo interno;
12. caja con ingresos por venta y movimientos manuales;
13. cierre de turno o cierre diario;
14. proveedores;
15. relación ProductoProveedor;
16. importación Excel de listas de precios;
17. carga de texto de WhatsApp;
18. revisión y aplicación asistida de costos/precios;
19. etiquetas pendientes y etiquetas/listados imprimibles;
20. reportes básicos;
21. auditoría de acciones críticas.

## Prioridades funcionales

| Prioridad | Módulo | Justificación |
|---|---|---|
| Alta | Productos | Base del catálogo, ventas, stock y precios. |
| Alta | Stock por vencimiento | Problema central de la dietética. |
| Alta | Venta simplificada | Integra scanner, stock y caja. |
| Alta | Caja | Permite trazabilidad del dinero operativo. |
| Alta | Usuarios y roles | Protege información y registra responsables. |
| Alta | Auditoría | Sostiene la defensa de trazabilidad. |
| Media | Ofertas | Aporta realismo comercial y control de precios. |
| Media | Consumo interno | Evita faltantes sin explicación. |
| Media | Etiquetas | Necesidad frecuente de mostrador. |
| Alta | Proveedores y listas | Permite resolver actualización de costos y precios, un problema real del negocio. |
| Alta | Actualización asistida | Evita cambios automáticos riesgosos y conserva aprobación humana. |
| Media | Excel/WhatsApp/manual | Facilita carga de listas según cómo trabaja cada proveedor. |
| Media | Reportes | Agrega valor de gestión. |
| Baja inicial | Integraciones externas | Se deja preparado para evolución. |

## Observación final

El alcance queda bien posicionado si se presenta como un **sistema interno integrado de gestión operativa**, no como un POS fiscal. La fortaleza del TPF está en modelar correctamente los procesos reales: venta simple, caja, stock por vencimiento, ofertas, consumo interno, proveedores, listas de precios, actualización asistida, etiquetas pendientes y auditoría.
