---
title: "MVP - Version Minima Viable"
tags:
  - planificacion
  - mvp
  - alcance
---

# MVP - Version Minima Viable

> [!info] El MVP debe demostrar el flujo principal completo: tienda online con MP, venta presencial con caja, stock por lotes y trazabilidad.

---

## Criterio de exito

```text
Cliente se registra e inicia sesion (rol CUSTOMER)
    ↓
Cliente navega catalogo
    ↓
Cliente agrega al carrito local
    ↓
Cliente confirma compra → orden ONLINE (PENDING_PAYMENT)
    ↓
Cliente es redirigido a Mercado Pago Checkout Pro
    ↓
Cliente paga en MP
    ↓
MP envia webhook → backend verifica y aprueba pago
    ↓
Sistema descuenta stock FEFO
    ↓
Empleado prepara y entrega

VENTA PRESENCIAL:
    ↓
Empleado abre caja (monto inicial)
    ↓
Empleado registra venta POS (caja abierta requerida)
    ↓
Sistema descuenta stock FEFO, registra payment en caja
    ↓
Empleado cierra caja
    ↓
Sistema calcula efectivo esperado vs contado
    ↓
Si hay diferencia, se exige explicacion
```

## Alcance incluido

| Area | Incluye |
|---|---|
| Autenticacion | Registro de cliente, login, JWT |
| Sucursales | 1 sucursal real, entidad preparada para mas |
| Productos | ABM, categorias, precio, marca texto, imagen unica |
| Catalogo online | Productos publicados, busqueda, detalle |
| Carrito | LocalStorage en frontend |
| Tienda online | MP Checkout Pro, webhook, solo retiro |
| Caja | Apertura, movimientos, cierre con arqueo de efectivo |
| Ventas presenciales | POS con caja, multiples medios de pago |
| Stock | Lotes con vencimiento, FEFO, movimientos |
| Pagos | Tabla unificada para online y presenciales |
| Proveedores | Registro, asociacion producto, costo manual |
| Reportes | Dashboard, reporte de caja, recomendaciones |
| Roles | ADMIN, MANAGER, EMPLOYEE, CUSTOMER |

## Alcance excluido

| Funcionalidad | Motivo |
|---|---|
| Envio a domicilio | Solo retiro en sucursal |
| Carrito persistente en BD | Se usa localStorage |
| Facturacion fiscal | Excede alcance academico |
| App mobile nativa | Duplica esfuerzo |
| Multiempresa | Unico negocio |
| Logistica externa | Post-MVP |
| Importacion automatica | Post-MVP |

---

> [!seealso] Notas relacionadas
> - [[Epicas]]
> - [[User Stories]]
> - Volver a [[_Index]]
