---
title: "User Stories"
tags:
  - planificacion
  - user-stories
  - backlog
---

# User Stories (MVP)

---

## Cliente (CUSTOMER)

- Como cliente, quiero registrarme con email y contrasena para poder comprar online.
- Como cliente, quiero iniciar sesion para acceder a mis pedidos.
- Como cliente, quiero ver el catalogo online para conocer los productos disponibles.
- Como cliente, quiero agregar productos al carrito local para preparar mi compra.
- Como cliente, quiero pagar con Mercado Pago Checkout Pro para completar mi compra.
- Como cliente, quiero consultar el estado de mis pedidos para saber cuando retirarlos.

---

## Administrador

- Como administrador, quiero crear y editar productos para mantener el catalogo.
- Como administrador, quiero gestionar el stock por lotes y movimientos.
- Como administrador, quiero ver alertas de stock bajo y vencimientos.
- Como administrador, quiero abrir y cerrar caja para controlar el efectivo.
- Como administrador, quiero ver el reporte de cierre con totales por medio de pago.
- Como administrador, quiero gestionar proveedores y costos.
- Como administrador, quiero ver el dashboard con metricas del negocio.
- Como administrador, quiero gestionar usuarios internos.

---

## Empleado

- Como empleado, quiero abrir caja al comenzar mi turno.
- Como empleado, quiero escanear productos y cobrar con distintos medios de pago.
- Como empleado, quiero registrar movimientos manuales de caja si es necesario.
- Como empleado, quiero cerrar caja y que el sistema calcule la diferencia de efectivo.
- Como empleado, quiero preparar pedidos online para retiro.
- Como empleado, quiero marcar pedidos como listos y entregados.

---

> [!seealso] Notas relacionadas
> - [[Epicas]]
> - [[MVP]]
> - Volver a [[_Index]]
