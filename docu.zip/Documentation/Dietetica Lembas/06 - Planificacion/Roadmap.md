---
title: "Roadmap e Iteraciones"
tags:
  - planificacion
  - roadmap
  - iteraciones
  - futuro
---

# Roadmap e Iteraciones (MVP)

> [!info] Iteraciones para desarrollo individual del MVP.

---

## Iteraciones

### Iteracion 1 -- Base
- Autenticacion y registro de usuarios
- Roles basicos (ADMIN, MANAGER, EMPLOYEE, CUSTOMER)
- Sucursales
- Productos y categorias

### Iteracion 2 -- Tienda online
- Catalogo publico
- Busqueda y filtros
- Detalle de producto
- Carrito local (localStorage)
- Creacion de orden online

### Iteracion 3 -- Mercado Pago Checkout Pro
- Creacion de preferencia de pago
- Redireccion a MP
- Webhook y verificacion
- Actualizacion de orden y descuento FEFO
- Manejo de STOCK_CONFLICT

### Iteracion 4 -- Stock
- Lotes con vencimiento
- Ingresos de stock
- Movimientos de stock
- FEFO

### Iteracion 5 -- Caja operativa y POS
- Apertura de caja
- Venta presencial con scanner y multiples medios de pago
- Payment asociado a caja
- Movimientos manuales de caja
- Cierre de caja con arqueo de efectivo

### Iteracion 6 -- Proveedores y costos
- Proveedores
- Asociacion producto-proveedor
- Costo manual

### Iteracion 7 -- Reportes
- Dashboard basico
- Reporte de cierre de caja
- Recomendaciones por reglas

---

## Roadmap futuro (post-MVP)

| Funcionalidad | Prioridad |
|---|---|
| Envio a domicilio | Media |
| Promociones mas complejas | Baja |
| Multiples imagenes por producto | Baja |
| Importacion automatica de listas | Baja |
| App mobile | Baja |
| Multiempresa | Baja |

---

> [!seealso] Notas relacionadas
> - [[MVP]] -- alcance del MVP
> - Volver a [[_Index]]
