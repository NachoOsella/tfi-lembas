---
title: "Epicas del Proyecto"
tags:
  - planificacion
  - epicas
  - backlog
---

# Epicas del Proyecto (MVP)

---

## EP-01 -- Autenticacion y registro
Registro de clientes (CUSTOMER), login, JWT, perfil.

## EP-02 -- Gestion de catalogo
Productos, categorias, precio, marca, imagen, visibilidad online.

## EP-03 -- Tienda online
Catalogo publico, busqueda, carrito local, creacion de orden.

## EP-04 -- Mercado Pago Checkout Pro
Preferencia de pago, redireccion, webhook, verificacion, actualizacion de orden.

## EP-05 -- Stock
Lotes con vencimiento, movimientos, FEFO, alertas.

## EP-06 -- Pedidos
Ordenes unificadas (POS y ONLINE), cambios de estado, cancelacion.

## EP-07 -- Caja operativa
Apertura, movimientos manuales, ventas POS, cierre con arqueo de efectivo.

## EP-08 -- Ventas presenciales (POS)
Venta rapida con scanner, multiples medios de pago, descuento FEFO.

## EP-09 -- Pagos unificados
Tabla payments, asociacion a ordenes y caja, integracion MP.

## EP-10 -- Proveedores
Registro, asociacion producto-proveedor, costo manual.

## EP-11 -- Reportes y recomendaciones
Dashboard, reporte de cierre de caja, recomendaciones.

## EP-12 -- Usuarios y roles
Gestion de usuarios internos, permisos, caja.

---

> [!seealso] Notas relacionadas
> - [[MVP]]
> - [[User Stories]]
> - Volver a [[_Index]]
